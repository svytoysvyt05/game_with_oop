#include "characteristics.hpp"
#include <algorithm>
#include <cstdlib>
namespace creature{
        Charasteristic::Charasteristic(type_charasteristic type, int value)
            : proficiency_skill(0), proficiency_save(false), type(type) {
            // Проверка значения
            if (value < 0 || value > 20) { // Предположим, что допустимый диапазон от 1 до 20
                throw std::invalid_argument("Value must be between 1 and 20.");
            }
            this->value = value; // Инициализация value после проверки
        }

        Charasteristic::Charasteristic(type_charasteristic type, int value, int proficiency_skill,
         int proficiency_save) :  Charasteristic(type, value) {

            if (proficiency_skill <0) {
                throw std::invalid_argument("mistake");
            }
            this->proficiency_skill = proficiency_skill;
            this->proficiency_save = proficiency_save;
        }

        Charasteristic Charasteristic::operator+( const Charasteristic& operand) const{
            if( (int)type == (int) operand.get_type()) return Charasteristic{type, std::min(20, value + operand.get_value()), proficiency_skill+ operand.get_proficiency_skill(), proficiency_save+ operand.get_proficiency_save()};
            throw std::invalid_argument("different type");
        }
        Charasteristic Charasteristic::operator-( const Charasteristic& operand) const{
            if( (int)type == (int) operand.get_type()) return Charasteristic{type, std::max(1, value-operand.get_value()), std::max(0, proficiency_skill - operand.get_proficiency_skill()), std::max(0,proficiency_save- operand.get_proficiency_save())};
            throw std::invalid_argument("different type");
        }
        int Charasteristic::modifier() const{
            return (value -10)/2;
        }
        int Charasteristic::roll_skill() const{
            return rand()%20 + 1 + modifier() + proficiency_skill;
        }
        int Charasteristic::roll_save() const{
            return rand()%20 + 1 + modifier() + proficiency_save;
        }

        Characteristics_table::Characteristics_table(): speed(30){
                characteristics = {
                Charasteristic{type_charasteristic::Strength, 8},
                Charasteristic{type_charasteristic::Constitution, 8},
                Charasteristic{type_charasteristic::Dexterity, 8},
                Charasteristic{type_charasteristic::Intelligence, 8},
                Charasteristic{type_charasteristic::Wisdom, 8},
                Charasteristic{type_charasteristic::Charisma, 8}
                };
                max_HP = 8 + characteristics[1].modifier();
        }

        // Конструктор с параметрами
        Characteristics_table::Characteristics_table(std::vector<Charasteristic>& characteristics) {
            if( characteristics.size() != 6) throw std::invalid_argument("mistake characteristics. need is 6.");
            for (int i = 0; i <(int) characteristics.size(); i++) {
                if(((int) characteristics[i].get_type()) != i )
                 throw std::invalid_argument("mistake type characteristics. ");
            }
            this->characteristics = characteristics;
            max_HP = 8 + characteristics[1].modifier();
        }

        // Конструктор с параметрами
        Characteristics_table::Characteristics_table(std::vector<Charasteristic>& characteristics1, int max_HP1):Characteristics_table(characteristics1) {
            if(max_HP1>0)max_HP = max_HP1;
            else throw std::invalid_argument("mistake max_HP. need is positive .");
        }
        Characteristics_table::Characteristics_table(std::vector<Charasteristic>& characteristics1, int max_HP1, int speed1):Characteristics_table(characteristics1, max_HP1) {
            if(speed1>0) speed = speed1;
            else throw std::invalid_argument("mistake speed. need is positive .");
        }

        Characteristics_table& Characteristics_table::operator +=(const Dop_table_characteristics& operand){
            std::vector<Charasteristic> result(characteristics.size());

            std::transform(characteristics.begin(), characteristics.end(), operand.get_dop_characteristics().begin(), result.begin(), 
                        [](Charasteristic a, Charasteristic b) { return a + b; });
            max_HP += operand.get_dop_HP();
            speed += operand.get_dop_speed();
            characteristics = result;
            return *this;

        }
        Characteristics_table& Characteristics_table::operator -=(const Dop_table_characteristics& operand){
            std::vector<Charasteristic> result(characteristics.size());

            std::transform(characteristics.begin(), characteristics.end(), operand.get_dop_characteristics().begin(), result.begin(), 
                        [](Charasteristic a, Charasteristic b) { return a - b; });
            max_HP -= operand.get_dop_HP();
            speed -= operand.get_dop_speed();
            characteristics = result;
            return *this;

        }
        Dop_table_characteristics::Dop_table_characteristics(std::string name, int dop_HP, int move, int dop_speed, std::vector<Charasteristic> dop_characteristics) : Dop_table_characteristics(){
            if (!(name.empty() || move<1 || dop_HP<0 || dop_speed <0 || dop_characteristics.capacity() != 6 || dop_characteristics.size() !=6)){
                (*this).name = name;
                (*this).dop_HP = dop_HP;
                (*this).dop_speed = dop_speed;
                (*this).dop_characteristics = dop_characteristics;
                (*this).move = move;
            }else throw std::invalid_argument("mistake");
        }
	    void Dop_table_characteristics::set_name(std::string name1){
            if(!name1.empty()) name = name1;
            else throw std::invalid_argument("mistake");
        }
	    void Dop_table_characteristics::set_dop_HP(int dop_HP){
            if(dop_HP >=0) (*this).dop_HP = dop_HP;
            else throw std::invalid_argument("mistake");
        }
	    void Dop_table_characteristics::set_dop_speed(int dop_speed){
            if(dop_speed >=0) (*this).dop_speed = dop_speed;
            else throw std::invalid_argument("mistake");
        }
	    void Dop_table_characteristics::set_dop_characteristics(std::vector<Charasteristic> dop_characteristics){
            if(dop_characteristics.capacity() == 6 && dop_characteristics.size() == 6) this->dop_characteristics = dop_characteristics;
            else throw std::invalid_argument("mistake");
        }
	    void Dop_table_characteristics::set_move(int move){
            if(move >=0) (*this).move = move;
        }
	    std::string Dop_table_characteristics::get_name() const{
            return name;
        }
	    int Dop_table_characteristics::get_dop_HP() const{
            return dop_HP;
        }
	    int Dop_table_characteristics::get_dop_speed() const{
            return dop_speed;
        }
	    std::vector<Charasteristic> Dop_table_characteristics::get_dop_characteristics() const{
            return dop_characteristics;
        }
	    int Dop_table_characteristics::get_move() const{
            return move;
        }
        Dop_table_characteristics Dop_table_characteristics::operator +(const Dop_table_characteristics& operand) const{
            std::vector<Charasteristic> result(dop_characteristics.size());   
            std::transform(dop_characteristics.begin(), dop_characteristics.end(), operand.dop_characteristics.begin(), result.begin(), 
                        [](Charasteristic a, Charasteristic b) { return a + b; });
            return Dop_table_characteristics{name +operand.get_name(), dop_HP + operand.get_dop_HP(), move + operand.get_move(), dop_speed + operand.get_dop_speed(),result};
        }
   
}