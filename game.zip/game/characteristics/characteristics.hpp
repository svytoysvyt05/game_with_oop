#ifndef  CHARACTERISTICS_HPP
#define  CHARACTERISTICS_HPP
#include <stdexcept>
#include <string>
#include <vector>
#include <algorithm>

namespace creature{


/**
 * @brief  type the characteristics of a creature.
 * 
 */
enum class type_charasteristic{
        Strength = 0,
        Constitution,
        Dexterity,
        Intelligence,
        Wisdom,
        Charisma
};
class Dop_table_characteristics;
/**
 * @brief  A class to represent the characteristics of a creature.
 * 
 */
class Charasteristic{
        private:
        /**
         * @brief  The value of the characteristic.
         * 
         */
        int value=0;
        /**
         * @brief  The type of the characteristic.
         * 
         */
        int proficiency_skill = 0;
        /**
         * @brief  The bonus of the characteristic.
         * 
         */
        int proficiency_save = 0;
        type_charasteristic type;

        public:
        /** 
         * @brief  Constructor of the class.
         */
        Charasteristic(type_charasteristic type, int value, int proficiency_skill, int proficiency_save);
        Charasteristic(type_charasteristic type, int value);
        Charasteristic() = default;
        ~Charasteristic(){
        }
        /**
         * @brief Get the value object
         * 
         * @return int 
         */
        int get_value() const{
                return value;
        }
        /**
         * @brief Get the proficiency skill object
         * 
         * @return int 
         */
        int get_proficiency_skill()const{
                return proficiency_skill;
        }
        /**
         * @brief Get the proficiency save object
         * 
         * @return int 
         */
        int get_proficiency_save()const{
                return proficiency_save;
        }
        /**
         * @brief Get the type object
         * 
         * @return type_charasteristic 
         */
        type_charasteristic get_type()const{
                return type;
        }
        /**
         * @brief Set the value object
         * 
         * @param value 
         */
        void set_value(int value){
                if(value <=20 && value >= 0){
                        this->value = value;
                }else throw std::invalid_argument("mistake value");
        }
        /**
         * @brief Set the proficiency skill object
         * 
         * @param proficiency_skill 
         */
        void set_proficiency_skill(int proficiency_skill){
                if( proficiency_skill >= 0) {
                        this->proficiency_skill = proficiency_skill;
                }else throw std::invalid_argument("mistake proficiency_skill");
        }
        /**
         * @brief Set the proficiency save object
         * 
         * @param proficiency_save 
         */
        void set_proficiency_save(int proficiency_save){
                if( proficiency_save >= 0) {
                        this->proficiency_save = proficiency_save;
                }else throw std::invalid_argument("mistake proficiency_save");
        }
        /**
         * @brief Set the type object
         * 
         * @param type 
         */
        void set_type(type_charasteristic type){
                this->type = type;
        }
        /**
         * @brief  operations
         * 
         * @param operand 
         * @return Charasteristic 
         */
        Charasteristic operator +(const Charasteristic& operand) const;
        Charasteristic operator-( const Charasteristic& operand) const;
        Charasteristic operator +=(int value){
                this->value = std::max(std::min(this->value+value,20), 1);
                return *this;
        };
        /**
         * @brief  modifier
         * 
         * @return int 
         */
        int modifier() const;

        /**
         * @brief  roll
         * 
         * @return int 
         */
        int roll_skill() const;

        /**
         * @brief  roll
         * 
         * @return int 
         */
        int roll_save() const;

        /**
         * @brief  ==
         * 
         * @param a 
         * @return true 
         * @return false 
         */
        bool operator==(const Charasteristic& a) const{
                if(a.get_proficiency_save() == proficiency_save && a.get_proficiency_skill() == proficiency_skill &&
                (int) a.get_type() == (int) type && a.get_value() == value) return true;
                return false;
        }

        /**
         * @brief  !=
         * 
         * @param a 
         * @return true 
         * @return false 
         */
        bool operator!=(const Charasteristic& a) const{
                return !(*this == a);
        }
};

class Characteristics_table{
        private:
        std::vector<Charasteristic> characteristics;
        int max_HP;
        int speed = 6;

        public:
        Characteristics_table();
        ~Characteristics_table(){}
        Characteristics_table(const Characteristics_table & other){
                this->characteristics = other.characteristics;
                this->max_HP = other.max_HP;
        }
        Characteristics_table(std::vector<Charasteristic> &characteristics, int max_HP);
        Characteristics_table(std::vector<Charasteristic> &characteristics, int max_HP, int speed);
        Characteristics_table(std::vector<Charasteristic> &characteristics);
        void set_characteristics_table(std::vector<Charasteristic> characteristics){
                if(characteristics.capacity() == 6 && characteristics.size() == 6) this->characteristics = characteristics;
                else throw std::invalid_argument("mistake characteristics1");
    }
        void set_max_HP(int max_HP){
                if(max_HP>0) this->max_HP = max_HP;
                else throw std::invalid_argument("mistake max_HP");
        }
        
        void set_speed(int speed){
                if(speed>=0) this->speed = speed;
                else throw std::invalid_argument("mistake speed");
        }
        const std::vector<Charasteristic> get_characteristics_table() const{
                std::vector<Charasteristic> result{characteristics};
                return result;
        }
        int get_max_HP()const{
                return max_HP;
        }

        int get_speed()const{
                return speed;
        }

        int modifier(type_charasteristic type) const{
                auto iter = std::find_if(characteristics.begin(), characteristics.end(), [type]( Charasteristic a){return (int) a.get_type() == (int) type;});
                if(iter == characteristics.end()) throw std::invalid_argument("mistake type");
                int sum = iter->modifier();
                return sum;               
        }
        void level_up(){
                std::for_each(characteristics.begin(), characteristics.end(), [](Charasteristic &a){a+=1;});
                max_HP +=10;
        }
        int check_save(type_charasteristic type) const{
                auto iter = std::find_if(characteristics.begin(), characteristics.end(), [type]( Charasteristic a){return (int) a.get_type() == (int) type;});
                if(iter == characteristics.end()) throw std::invalid_argument("mistake type");
                int sum = iter->roll_save();
                return sum;
        }
        int check_save(int dc, type_charasteristic type)const{
                return check_save(type) >= dc ? 1 : 0;
        }
        int check_skill(type_charasteristic type)const{
                auto iter = std::find_if(characteristics.begin(), characteristics.end(), [type]( Charasteristic a){return (int) a.get_type() == (int) type;});
                if(iter == characteristics.end()) throw std::invalid_argument("mistake type");
                int sum = iter->roll_skill();
                return sum;
        }
        int check_skill(int dc, type_charasteristic type)const{
                return check_skill(type) >= dc ? 1 : 0;
        }
        auto get_characteristic(type_charasteristic type)const{
                auto iter = std::find_if(characteristics.begin(), characteristics.end(), [type]( Charasteristic a){return (int) a.get_type() == (int) type;});
                if(iter == characteristics.end()) throw std::invalid_argument("mistake type ");
                return iter;
        }
        void set_characteristic(type_charasteristic type, int value, int skill = 0, int save = 0){
                auto iter = std::find_if(characteristics.begin(), characteristics.end(), [type]( Charasteristic a){return (int) a.get_type() == (int) type;});
                if(iter == characteristics.end()) throw std::invalid_argument("mistake type ");
                if(value> 1 && value <= 20 && skill >=0 && save >= 0){
                         iter->set_value(value );
                         iter->set_proficiency_skill(skill);
                         iter->set_proficiency_save(save);
                }else throw std::invalid_argument("mistake characteristic");
        }      
        Characteristics_table& operator +=(const Dop_table_characteristics& operand);
        Characteristics_table& operator -=(const Dop_table_characteristics& operand);
        bool operator==(const Characteristics_table& a) const{
                if(std::equal(characteristics.begin(), characteristics.end(), a.get_characteristics_table().begin()) &&
                 a.get_max_HP() == max_HP && a.get_speed() == speed) return true;
                return false;                
        }
        bool operator!=(const Characteristics_table& a) const{
                return !(*this == a);
        }
        Characteristics_table& operator=(const Characteristics_table& a){
                characteristics = a.get_characteristics_table();
                max_HP = a.get_max_HP();
                speed = a.get_speed();
                return *this;
        }
        int get_value_characteristics() const{return characteristics.size();}
};

class Dop_table_characteristics{
	private:
	std::string name = "dop characteristics";
	int dop_HP = 0;
	int dop_speed = 0;
	std::vector<Charasteristic> dop_characteristics{6, Charasteristic()};
	int move=1;

	public:
	Dop_table_characteristics() = default;
	Dop_table_characteristics(std::string name, int dop_HP, int move, int dop_speed, std::vector<Charasteristic> dop_characteristics);

	void set_name(std::string name1);
	void set_dop_HP(int dop_HP);
	void set_dop_speed(int dop_speed);
	void set_dop_characteristics(std::vector<Charasteristic> dop_characteristics);
	void set_dop_characteristic(Charasteristic& dop_characteristic){
                auto char1 = std::find_if( dop_characteristics.begin(), dop_characteristics.end(),
                 [&](const Charasteristic& c){return c.get_type() == dop_characteristic.get_type();});
                if(char1 != dop_characteristics.end()) *char1 = dop_characteristic;
                else throw std::invalid_argument("mistake characteristic");
        }
	void set_move(int move);
        void operator--(int){
                move--;
        }
	std::string get_name()const;
	int get_dop_HP()const;
	int get_dop_speed()const;
	std::vector<Charasteristic> get_dop_characteristics()const;
	int get_move()const;
        Dop_table_characteristics operator +(const Dop_table_characteristics& operand) const;
};      

}

#endif
