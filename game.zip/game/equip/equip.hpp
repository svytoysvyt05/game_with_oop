#ifndef EQUIP_H
#define EQUIP_H
#include "../item/item.hpp"
#include "../characteristics/characteristics.hpp"
#include <stdexcept>
namespace creature{
class Creature;
class Characteristics_table;
}
namespace item{

enum class type_protect{
        armor,
        shield,
        cape,
        necklace,
        ring
};

typedef struct Enchanted{
        std::string magics;
        double modifier;
} Enchanted;

class IAttacked{
        public:
        virtual int attack(creature::Characteristics_table table) = 0;
        virtual int damage(creature::Characteristics_table table, std::string feauters) = 0;
        // virtual int distance() = 0;
};

/**
 * @brief  The Weapon:  class  
 * 
 */
class Weapon:  public IAttacked, public Item{
        friend class Magic_Weapon;
        friend class Artefact_Weapon;
        friend class Artefact_Magic_Weapon;
        private:
        int min_damage;
        int max_damage;
        creature::type_charasteristic type;
        int distance = 1;


        public:
        /**
         * @brief Construct a new Weapon object
         * 
         * @param a 
         */
        Weapon(const Weapon& a): Item(a.get_name(),a.get_value(), a.get_description()){
                this->min_damage = a.min_damage;
                this->max_damage = a.max_damage;
                this->type = a.type;
                this->distance = a.distance;
        };
        Weapon(Weapon&& a){
                this->min_damage = a.min_damage;
                this->max_damage = a.max_damage;
                this->type = a.type;
                this->distance = a.distance;
                a.min_damage = 0;
                a.max_damage = 0;
                a.distance = 0;
        }
        virtual ~Weapon() = default;
        Weapon(): Item("fists", 1, "Everyone has a fist"), min_damage(1), max_damage(1), type(creature::type_charasteristic::Strength){}
        Weapon(std::string name, int min_damage, int max_damage, int distance, creature::type_charasteristic type);
        Weapon(std::string name, std::string description, int min_damage, int max_damage, int distance, creature::type_charasteristic type);
        /**
         * @brief Get the min damage object
         * 
         * @return int 
         */
        int get_min_damage()const{
                return min_damage;
        }

        /**
         * @brief Get the max damage object
         * 
         * @return int 
         */
        int get_max_damage()const{
                return max_damage;
        }

        /**
         * @brief Get the distance object
         * 
         * @return int 
         */
        int get_distance()const{
                return distance;
        }
        /**
         * @brief Get the type object
         * 
         * @return creature::type_charasteristic 
         */
        creature::type_charasteristic get_type()const{
                return type;
        }
        /**
         * @brief Set the distance object
         * 
         * @param distance 
         */
        void set_distance(int distance){
                if(distance>=1) this->distance = distance;
                else throw std::invalid_argument("Distance must be greater than 0");
        }

        /**
         * @brief Set the min damage object
         * 
         * @param min_damage 
         */
        void set_min_damage(int min_damage){
                if(min_damage>=0) this->min_damage = min_damage;
                else throw std::invalid_argument("Min damage must be greater than 0");
        }
        /**
         * @brief Set the max damage object
         * 
         * @param max_damage 
         */
        void set_max_damage(int max_damage){
                if(max_damage>=0 && max_damage>=min_damage) this->max_damage = max_damage;
                else throw std::invalid_argument("Max damage must be greater than 0 and greater than min damage");
        }
        /**
         * @brief Set the type object
         * 
         * @param type 
         */
        void set_type(creature::type_charasteristic type){
                this->type = type;
        }
        /**
         * @brief attack
         * 
         * @param table 
         * @return int 
         */
        int attack(creature::Characteristics_table table)override;

        /**
         * @brief  damage
         * 
         * @param table 
         * @param feauters 
         * @return int 
         */
        int damage(creature::Characteristics_table table, std::string feauters) override;
        
        /**
         * @brief removed
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override{
                return;
        }

        /**
         * @brief  putted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override{
                return;
        }
        /**
         * @brief copy
         * 
         * @param a 
         * @return Weapon& 
         */
        Weapon& operator=(const Weapon& a){
                if(this != &a){
                        name = a.name;
                        description = a.description;
                        min_damage = a.min_damage;
                        max_damage = a.max_damage;
                        distance = a.distance;
                        type = a.type;
                }
                return *this;
        }

        /**
         * @brief  move
         * 
         * @param a 
         * @return Weapon& 
         */
        Weapon& operator=(Weapon&& a) noexcept{
                if(this != &a){
                        name = a.name;
                        description = a.description;
                        min_damage = a.min_damage;
                        max_damage = a.max_damage;
                        distance = a.distance;
                        type = a.type;
                }
                return *this;
        }

        /**
         * @brief  ==
         * 
         * @param other 
         * @return true 
         * @return false 
         */
        bool operator== (const Weapon& other)const{
                return name == other.name && min_damage == other.min_damage && max_damage == other.max_damage
                 && distance == other.distance && type == other.type;
        }
        /**
         * @brief !=
         * 
         * @param other 
         * @return true 
         * @return false 
         */
        bool operator!= (const Weapon& other)const{ return !(*this == other); }

        Weapon* clone() const override{
                return new Weapon(*this);
        }
};

class Magic_Weapon:  public Weapon{
        protected:
        /**
         * @brief  Magic_Weapon enchanteds
         * 
         */
        std::vector<Enchanted> enchanteds;

        public:
        /**
         * @brief Construct a new Magic_Weapon object
         * 
         * @param a 
         */
        Magic_Weapon(const Magic_Weapon& a) = default;
        Magic_Weapon(Magic_Weapon&& a) = default;
        virtual ~Magic_Weapon() = default;
        Magic_Weapon(): Weapon(), enchanteds(){}
        Magic_Weapon(std::string name, int min_damage, int max_damage, int distance,
        creature::type_charasteristic type, std::vector<Enchanted> enchanteds):
        Weapon(name, "", min_damage, max_damage, distance, type), enchanteds(enchanteds ){}

        Magic_Weapon(std::string name, std::string description, int min_damage, int max_damage,
        int distance, creature::type_charasteristic type, std::vector<Enchanted> enchanteds):
        Weapon(name, description, min_damage, max_damage, distance, type), enchanteds(enchanteds ){}

/**
 * @brief Set the enchanteds object
 * 
 * @param enchanteds 
 */
        void set_enchanteds(std::vector<Enchanted> enchanteds);

        /**
         * @brief Get the enchanteds object
         * 
         * @return std::vector<Enchanted> 
         */
        std::vector<Enchanted> get_enchanteds(){
                return enchanteds;
        }

        /**
         * @brief 
         * 
         * @param table 
         * @param feauters 
         * @return int 
         */
        int damage(creature::Characteristics_table table, std::string feauters) override;
\
        Magic_Weapon* clone() const override{
                return new Magic_Weapon(*this);
        }
};

class Artefact_Weapon:  public Weapon{
        protected:
        creature::Dop_table_characteristics *dop_table = nullptr;
        public:
        /**
         * @brief Construct a new Artefact_Weapon object
         * 
         * @param a 
         */
        Artefact_Weapon(const Artefact_Weapon& a) = default;
        
        Artefact_Weapon(Artefact_Weapon&& a) = default;
        
        virtual ~Artefact_Weapon() = default;
        
        Artefact_Weapon(): Weapon(), dop_table(nullptr){}
        
        Artefact_Weapon(std::string name, int min_damage, int max_damage, int distance
        , creature::type_charasteristic type, creature::Dop_table_characteristics *dop):
        Weapon(name, "", min_damage, max_damage, distance, type){
                if(dop)dop_table = dop;
         }

        Artefact_Weapon(std::string name, std::string description, int min_damage, int max_damage,
         int distance, creature::type_charasteristic type,
         creature::Dop_table_characteristics *dop):
         Weapon(name, description, min_damage, max_damage, distance, type){
                if(dop)dop_table = dop;
         }
        /**
         * @brief Set the dop table object
         * 
         * @param dop_table 
         */
        void set_dop_table(creature::Dop_table_characteristics *dop_table){
                if(dop_table) delete dop_table;
                this->dop_table = dop_table;
        }
        /**
         * @brief Get the dop table object
         * 
         * @return creature::Dop_table_characteristics* 
         */
        creature::Dop_table_characteristics* get_dop_table()const{
                return dop_table;
       }
        /**
         * @brief 
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override;
        void Puted(creature::Creature* person) override;

        Artefact_Weapon* clone() const override{
                return new Artefact_Weapon(*this);
        }
};

class Artefact_Magic_Weapon: public Weapon{
        private:
        creature::Dop_table_characteristics *dop_table = nullptr;
        std::vector<Enchanted> enchanteds;
        public:
        /**
         * @brief Construct a new Artefact_Magic_Weapon object
         * 
         * @param a 
         */
        Artefact_Magic_Weapon(const Artefact_Magic_Weapon& a) = default;

        Artefact_Magic_Weapon(): Weapon(), dop_table(nullptr){}

        Artefact_Magic_Weapon(std::string name, std::string description, int min_damage, int max_damage,
          int distance, creature::type_charasteristic type, creature::Dop_table_characteristics *dop,
          std::vector<Enchanted> enchanteds);

        /**
         * @brief Set the dop table object
         * 
         * @param dop_table 
         */
        void set_dop_table(creature::Dop_table_characteristics *dop_table){
                if(dop_table) delete dop_table;
                this->dop_table = dop_table;
        }
        /**
         * @brief Get the dop table object
         * 
         * @return creature::Dop_table_characteristics* 
         */
        creature::Dop_table_characteristics* get_dop_table()const{
                return dop_table;
       }
       /**
        * @brief Set the enchanteds object
        * 
        * @param enchanteds 
        */
        void set_enchanteds(std::vector<Enchanted> enchanteds);
        /**
         * @brief Get the enchanteds object
         * 
         * @return std::vector<Enchanted> 
         */
        std::vector<Enchanted> get_enchanteds(){
                return enchanteds;
        }
        /**
         * @brief 
         * 
         * @param table 
         * @param feauters 
         * @return * int 
         */
        int damage(creature::Characteristics_table table, std::string feauters) override;

        /**
         * @brief Removed
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override;
        /**
         * @brief  Puted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override;

        Artefact_Magic_Weapon* clone() const override{
                return new Artefact_Magic_Weapon(*this);
        }

};

class Protect: public Item{

        protected:
        int dop_AC = 0;
        /**
         * @brief type
         * 
         */
        type_protect type = type_protect::ring;

        public:
        /**
         * @brief Construct a new Protect object
         * 
         */
        Protect() = default;
        Protect(type_protect type):Protect(){
                this->type = type;
        }
        Protect( int dop_AC, type_protect type):Protect(type){
                this->name = "protect";
                this->dop_AC = dop_AC;
        }
        Protect(std::string name, int dop_AC, type_protect type, std::string description = ""):Protect(type){
                if(!name.empty()){
                        this->dop_AC = dop_AC;
                        this->name = name;
                        this->description = description;
                } else throw std::invalid_argument("Name can't be empty");
        }
        /**
         * @brief Set the dop AC object
         * 
         * @param dop_AC 
         */
        void set_dop_AC(int dop_AC){
                if(dop_AC<0) this->dop_AC = dop_AC;
                throw std::invalid_argument("mistake AC");
        }
        /**
         * @brief Set the type object
         * 
         * @param type 
         */
        void set_type(type_protect type){
                this->type = type;
        }
        /**
         * @brief 
         * 
         * @return int 
         */
        int get_AC(){
                return dop_AC;
        } /**
         * @brief Get the type object
         * 
         * @return type_protect 
         */
        type_protect get_type(){
                return type;
        }
        /**
         * @brief Removed
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override;
        /**
         * @brief Puted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override;

        Protect* clone() const override{
                return new Protect(*this);
        }
};

class Artefact_Protect: public Protect{
        private:
        /**
         * @brief dop characteristic
         * 
         */
        creature::Dop_table_characteristics *dop_table = nullptr;
        public:
        /**
         * @brief Construct a new Artefact_Protect object
         * 
         */
        Artefact_Protect() : Protect(){
                dop_table = new creature::Dop_table_characteristics{};
        }

        Artefact_Protect(std::string name, int dop_AC, type_protect type, creature::Dop_table_characteristics *dop_table1, std::string description = ""):
         Protect(name, dop_AC, type, description){
                if(dop_table1)this->dop_table = dop_table1;
                else throw std::invalid_argument("table can't be empty");                
        }

        
/**
 * @brief Set the dop table object
 * 
 * @param dop_table 
 */
        void set_dop_table(creature::Dop_table_characteristics *dop_table){
                if(dop_table) this->dop_table = dop_table;
        }
        /**
         * @brief Get the dop table object
         * 
         * @return creature::Dop_table_characteristics* 
         */
        creature::Dop_table_characteristics* get_dop_table()const{
                return dop_table;
        }
/**
 * @brief Removed
 * 
 * @param person 
 */
        void Removed(creature::Creature* person) override;
        /**
         * @brief Puted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override;

        Artefact_Protect* clone() const override{
                return new Artefact_Protect(*this);
        }
};
}
#endif // DANG_H