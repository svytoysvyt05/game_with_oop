#include "equip.hpp"
#include "../characteristics/characteristics.hpp"
#include "../creater/creater.hpp"
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_set>

namespace item{
        Weapon::Weapon(std::string name, int min_damage, int max_damage, int distance, creature::type_charasteristic type):
        Item(name, 1){
                if(max_damage>=0 && max_damage>=min_damage && distance>0){
                        this->min_damage=min_damage;
                        this->max_damage=max_damage;
                        this->type = type;
                        this->distance = distance;
                }
        }

        Weapon::Weapon(std::string name, std::string description, int min_damage, int max_damage, int distance, creature::type_charasteristic type):
        Weapon( name, min_damage,  max_damage, distance, type){
                this->description = description;
        }

        int Weapon::attack(creature::Characteristics_table table){
                creature::type_charasteristic type1 = type;
                std::vector<creature::Charasteristic> characteristics1 = table.get_characteristics_table();
                auto iter = std::find_if(characteristics1.begin(), characteristics1.end(),
                 [type1](creature::Charasteristic a){return ((int) a.get_type()) == ((int) type1);});
                if(iter != table.get_characteristics_table().end()){
                        int attack = iter->roll_skill();
                        return attack;
                } else{
                         throw std::invalid_argument("You can't use this weapon");
                }
        }
        int Weapon::damage(creature::Characteristics_table table, std::string feauters){
                creature::type_charasteristic type1 = type;
                std::vector<creature::Charasteristic> characteristics1 = table.get_characteristics_table();
                auto iter = std::find_if(characteristics1.begin(), characteristics1.end(),
                 [type1](creature::Charasteristic a){return (int) a.get_type() == (int) type1;});
                if(iter != table.get_characteristics_table().end()){
                        int damage = iter->modifier() + min_damage + rand() % (max_damage - min_damage + 1);
                        return damage;
                } else throw std::invalid_argument("You can't use this weapon");                
        }

        int Magic_Weapon::damage(creature::Characteristics_table table, std::string feauters){
                creature::type_charasteristic type1 = type;
                std::vector<creature::Charasteristic> characteristics1 = table.get_characteristics_table();
                auto iter = std::find_if(characteristics1.begin(), characteristics1.end(),
                 [type1](creature::Charasteristic a){return (int) a.get_type() == (int) type1;});

             
                if(iter != table.get_characteristics_table().end()){
                        double damage = iter->modifier() + min_damage + rand() % (max_damage - min_damage + 1);
                        for (auto& elem : enchanteds) {
                                if (feauters==elem.magics) {
                                        damage *= elem.modifier;
                                        break;
                                }
                        }
                        return (int) damage;
                } else throw std::invalid_argument("You can't use this weapon");                
        }
        int Artefact_Magic_Weapon::damage(creature::Characteristics_table table, std::string feauters){
                creature::type_charasteristic type1 = type;
                std::vector<creature::Charasteristic> characteristics1 = table.get_characteristics_table();
                auto iter = std::find_if(characteristics1.begin(), characteristics1.end(),
                 [type1](creature::Charasteristic a){return (int) a.get_type() == (int) type1;});

             
                if(iter != table.get_characteristics_table().end()){
                        double damage = iter->modifier() + min_damage + rand() % (max_damage - min_damage + 1);
                        for (auto& elem : enchanteds) {
                                if (feauters==elem.magics) {
                                        damage *= elem.modifier;
                                        break;
                                }
                        }   
                        return (int) damage;
                }  else  throw std::invalid_argument("You can't use this weapon");                
        }
        void Artefact_Weapon::Puted(creature::Creature* person){
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->add_table(*dop_table);

                        }else throw std::runtime_error("dop_table is null");
                }
        }
        void Artefact_Weapon::Removed(creature::Creature* person){
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->minus_table(*dop_table);

                        }else throw std::runtime_error("dop_table is null");
                }
        }
        void Artefact_Magic_Weapon::Puted(creature::Creature* person){
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->add_table(*dop_table);

                        }else throw std::runtime_error("dop_table is null");
                }
        }



        Artefact_Magic_Weapon::Artefact_Magic_Weapon(std::string name, std::string description, int min_damage, int max_damage,
          int distance, creature::type_charasteristic type, creature::Dop_table_characteristics *dop,
          std::vector<Enchanted> enchanteds):
           Weapon(name, description, min_damage, max_damage, distance, type), enchanteds(enchanteds ){
                if(dop)dop_table = dop;

        }
        void Artefact_Magic_Weapon::Removed(creature::Creature* person){
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->minus_table(*dop_table);
                        }else throw std::runtime_error("dop_table is null");
                }
        }

        void Protect::Removed(creature::Creature* person) {
                person->set_armor_class(person->get_armor_class() + dop_AC);
        }
        
        void Protect::Puted(creature::Creature* person) {
                person->set_armor_class(person->get_armor_class() - dop_AC);
        }

        void Artefact_Protect::Removed(creature::Creature* person) {
                person->set_armor_class(person->get_armor_class() + dop_AC);
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->add_table(*dop_table);

                        }else throw std::runtime_error("dop_table is null");
                }
        }
        void Artefact_Protect::Puted(creature::Creature* person) {
                person->set_armor_class(person->get_armor_class() - dop_AC);
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1 != nullptr){
                        if(dop_table){
                                person1->minus_table(*dop_table);
                        }else throw std::runtime_error("dop_table is null");
                }
        }
}
