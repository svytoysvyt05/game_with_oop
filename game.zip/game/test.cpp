#include <string>
#define CATCH_CONFIG_MAIN
#include <catch2/catch_test_macros.hpp>
#include <catch2/catch_test_macros.hpp>
#include <catch2/internal/catch_to_string.hpp>
#include <catch2/matchers/catch_matchers.hpp>

#include "characteristics/characteristics.hpp"
#include "creater/creater.hpp"
#include "../view/view.hpp"
#include "dang/dang.hpp"
#include "equip/equip.hpp"
#include "item/item.hpp"
#include "level/level.hpp"
#include "one/one.hpp"
#include "openned/openned.hpp"
#include <vector>
#include <iostream>
namespace creature {
        TEST_CASE("Matrix"){
                dang::Matrix<int> matrix{};
                REQUIRE_NOTHROW(matrix.end());
                REQUIRE_NOTHROW(matrix.cend());
                REQUIRE_NOTHROW(matrix.begin());
                REQUIRE_NOTHROW(matrix.cbegin());
                dang::Matrix<int> matrix2{{1,2}, {2, 3}};
                REQUIRE(matrix2.size() == 4);
                for(int i = 0; i< matrix2.cols(); i++){
                        for(int j = 0; j < matrix2.rows(); j++){
                                REQUIRE(matrix2[i][j] == static_cast<int>(i+j)+1);
                        }
                }
                REQUIRE(matrix2.at(0,0) == 1);
                REQUIRE(matrix2.back() == 3);
                REQUIRE(matrix2.front() == 1);
                matrix2.erase(matrix2.begin());
                REQUIRE(matrix2[0][0] == 0);
                matrix2.insert(matrix2.begin(), 4);
                REQUIRE(matrix2[0][0] == 4);
                REQUIRE(matrix2.begin()[1] == 2);
                REQUIRE(matrix2.end() == matrix2.begin() + matrix2.size());
                REQUIRE(matrix2.cols() == 2);
                REQUIRE(matrix2.rows() == 2);
                REQUIRE(matrix2.empty() == false);
                matrix2[0][0] = 10;
                REQUIRE(matrix2.cbegin() == matrix2.begin());
                REQUIRE(matrix2.cend() == matrix2.end());
                int count = 0;
                for (auto it = matrix2.begin(); it != matrix2.end(); ++it) {
                        count++;
                }

                REQUIRE(count == 4); // Проверяем, что все элементы были перебраны
                REQUIRE(matrix2.data()[1] == 2);
                matrix.resize( 3, 3);
                REQUIRE(matrix.size() == 9);
                REQUIRE(matrix[0][2] == 0);
                
                matrix2.resize(3, 3);
                REQUIRE(matrix2.size() == 9);
                REQUIRE(matrix2[0][0] == 10);
                matrix2.clear();
                REQUIRE(matrix2.empty() == true);
                REQUIRE(matrix2.size() == 0);
                REQUIRE(matrix2.rows() == 0);
                REQUIRE(matrix2.cols() == 0);
                REQUIRE_THROWS( matrix2.insert(matrix2.begin()+1111, 8));


        }
        TEST_CASE("Charasteristic Constructor and Modifiers", "[Charasteristic]") {
                Charasteristic strength(type_charasteristic::Strength, 15, 4, 2);
                Charasteristic strength1(type_charasteristic::Strength, 15, 4, 2);
                REQUIRE_THROWS_AS(Charasteristic(type_charasteristic::Strength, 25), std::invalid_argument);
                REQUIRE_THROWS_AS(Charasteristic(type_charasteristic::Strength, 5, -5, 2), std::invalid_argument);
                REQUIRE(strength1 == strength);
                REQUIRE(strength1 != Charasteristic(type_charasteristic::Strength, 15, 4, -3));

                REQUIRE(strength.modifier() == 2); // (15 - 10) / 2
                REQUIRE(strength.roll_skill() > 6);
                REQUIRE(strength.roll_save() > 4);
                REQUIRE(strength.roll_skill() <= 26);
                REQUIRE(strength.roll_save() <= 24);
                REQUIRE((strength1+=3).get_value() == 18);
                REQUIRE((strength1+=22).get_value() == 20);
                REQUIRE((strength1+= -50).get_value() == 1);
                SECTION("+, -"){  
                        REQUIRE((strength + Charasteristic(type_charasteristic::Strength, 10,2 , 0) )
                        == Charasteristic(type_charasteristic::Strength, 20, 6, 2));
                        REQUIRE((strength + Charasteristic(type_charasteristic::Strength, 1,2 , 0) )
                        == Charasteristic(type_charasteristic::Strength, 16, 6, 2));

                        REQUIRE((strength - Charasteristic(type_charasteristic::Strength, 20,2 , 0) )
                        == Charasteristic(type_charasteristic::Strength, 1, 2, 2));
                        REQUIRE((strength - Charasteristic(type_charasteristic::Strength, 1,2 , 3) )
                        == Charasteristic(type_charasteristic::Strength, 14, 2, 0));
                        REQUIRE_THROWS_AS(strength - Charasteristic(type_charasteristic::Dexterity, 20,2 , 0), std::invalid_argument);
                        REQUIRE_THROWS_AS(strength + Charasteristic(type_charasteristic::Dexterity, 20,2 , 0), std::invalid_argument);
                }
                SECTION("getter"){
                        REQUIRE(strength.get_value() == 15);
                        REQUIRE(strength.get_proficiency_skill() == 4);
                        REQUIRE(strength.get_proficiency_save() == 2);
                        REQUIRE((int) strength.get_type() == (int) type_charasteristic::Strength);
                }

                SECTION("setter right"){
                        strength1.set_value(7);
                        strength1.set_proficiency_skill(3);
                        strength1.set_proficiency_save(3);
                        strength1.set_type(type_charasteristic::Wisdom);
                        REQUIRE(strength1.get_value() == 7);
                        REQUIRE(strength1.get_proficiency_skill() == 3);
                        REQUIRE(strength1.get_proficiency_save() == 3);
                        REQUIRE((int) strength1.get_type() == (int) type_charasteristic::Wisdom);        
                }

                SECTION("setter wrong"){
                        REQUIRE_THROWS_AS(strength.set_value(25), std::invalid_argument);
                        REQUIRE_THROWS_AS(strength.set_proficiency_skill(-9), std::invalid_argument);
                        REQUIRE_THROWS_AS(strength.set_proficiency_save(-9), std::invalid_argument);
                }
                }

        TEST_CASE("Characteristics Table Adding Characteristics", "[Characteristics_table]") {
                std::vector<Charasteristic> char_list = {
                        {type_charasteristic::Strength, 8, 4, 2},
                        {type_charasteristic::Constitution, 8, 4, 2},
                        {type_charasteristic::Dexterity, 8, 4, 2},
                        {type_charasteristic::Intelligence, 8},
                        {type_charasteristic::Wisdom, 8},
                        {type_charasteristic::Charisma, 8}
                };
                std::vector<Charasteristic> char_list1 = {
                        {type_charasteristic::Strength, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Dexterity, 8},
                        {type_charasteristic::Intelligence, 8},
                        {type_charasteristic::Charisma, 8},
                        {type_charasteristic::Wisdom, 8}
                };
                std::vector<Charasteristic> char_list2 = {
                        {type_charasteristic::Strength, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Constitution, 8},
                };
                Characteristics_table table2(char_list);
                Characteristics_table table1(char_list, 10);
                Characteristics_table table(char_list, 10, 2);
                REQUIRE_THROWS_AS(Characteristics_table(char_list1), std::invalid_argument); 
                REQUIRE_THROWS_AS(Characteristics_table(char_list, -2), std::invalid_argument); 
                REQUIRE_THROWS_AS(Characteristics_table(char_list, 5, -2), std::invalid_argument); 
                               
                SECTION("getter"){
                        table.level_up();
                        REQUIRE(table.get_characteristic(type_charasteristic::Strength)->get_value() == 9 );
                        REQUIRE(table.get_max_HP() == 20);
                        REQUIRE(table.get_speed() == 2);
                        REQUIRE(table.get_value_characteristics() == 6);
                }

                SECTION("setter right"){
                        table1.set_characteristics_table(char_list1);
                        table1.set_max_HP(15);
                        table1.set_speed(3);
                        REQUIRE((int) table1.get_characteristics_table()[5].get_type() == (int) type_charasteristic::Wisdom );
                        REQUIRE(table1.get_max_HP() == 15);
                        REQUIRE(table1.get_speed() == 3);
                }

                SECTION("setter wrong"){
                        REQUIRE_THROWS_AS(table.set_max_HP(-5), std::invalid_argument);
                        REQUIRE_THROWS_AS(table.set_speed(-5), std::invalid_argument);
                }
                REQUIRE(table.get_characteristics_table().size() == 6);

                table2.set_characteristics_table(char_list2);
                SECTION("checks"){
                        REQUIRE(table.modifier(type_charasteristic::Wisdom) == -1);
                        REQUIRE(table.check_skill(type_charasteristic::Strength) <= 23);
                        REQUIRE(table.check_skill(type_charasteristic::Strength) <= 21);
                        REQUIRE(table.check_skill(type_charasteristic::Strength) > 3);
                        REQUIRE(table.check_save(type_charasteristic::Strength) > 1);
                        REQUIRE_THROWS_AS(table2.check_skill(type_charasteristic::Wisdom), std::invalid_argument);
                        REQUIRE_THROWS_AS(table2.check_save(type_charasteristic::Wisdom) , std::invalid_argument);
                }
        }

    TEST_CASE("Creature Default Constructor", "[Creature]") {
                std::vector<Charasteristic> char_list = {
                Charasteristic{type_charasteristic::Strength, 8},
                Charasteristic{type_charasteristic::Constitution, 8},
                Charasteristic{type_charasteristic::Dexterity, 8},
                Charasteristic{type_charasteristic::Intelligence, 8},
                Charasteristic{type_charasteristic::Wisdom, 8},
                Charasteristic{type_charasteristic::Charisma, 8}
                };
                std::vector<Charasteristic> char_list1 = {
                Charasteristic{type_charasteristic::Strength, 8},
                Charasteristic{type_charasteristic::Constitution, 8},
                Charasteristic{type_charasteristic::Dexterity, 8},
                Charasteristic{type_charasteristic::Intelligence, 8},
                Charasteristic{type_charasteristic::Wisdom, 8},
                Charasteristic{type_charasteristic::Charisma, 8}
                };
                Creature creature{};
                REQUIRE(creature.get_name() == "name1");
                REQUIRE(creature.get_HP() == 9);
                REQUIRE(creature.get_armor_class() == 10);
                REQUIRE(creature.get_Y_pos() == 0);
                REQUIRE(creature.get_X_pos() == 0);
                REQUIRE(creature.get_cell() == nullptr);
                REQUIRE(std::equal(char_list1.begin(),
                 char_list1.end(), char_list.begin()));
                std::vector<Charasteristic> vec1 =creature.get_characteristics().get_characteristics_table();
                REQUIRE(std::equal(vec1.begin(),vec1.end(), char_list.begin()));

    }

    TEST_CASE("Player", "[Player]") {
                cell::Cell* cell = new cell::Cell{};
                std::vector<Charasteristic> char_list = {
                        {type_charasteristic::Strength, 16, 4, 2},
                        {type_charasteristic::Constitution, 15, 4, 2},
                        {type_charasteristic::Dexterity, 8},
                        {type_charasteristic::Intelligence, 11, 4, 0},
                        {type_charasteristic::Wisdom, 12, 0, 2},
                        {type_charasteristic::Charisma, 10}
                };
                std::vector<Charasteristic> char_list_dop = {
                        {type_charasteristic::Strength, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Dexterity, 8},
                        {type_charasteristic::Intelligence, 8},
                        {type_charasteristic::Wisdom, 8},
                        {type_charasteristic::Charisma, 8}

                };
                Player player{"player", 1, 1, 15, "human", new Characteristics_table{char_list}, cell,
                 0, 0, new item::Weapon{}, item::Master_keys(), 10, {}, {}, {}};
                REQUIRE(player.get_name() == "player");
                REQUIRE(player.get_HP() == 10);
                REQUIRE(player.get_armor_class() == 9);
                REQUIRE(player.get_Y_pos() == 0);
                REQUIRE(player.get_X_pos() == 0);
                std::vector<Charasteristic> vec1 =player.get_characteristics().get_characteristics_table();
                REQUIRE(player.get_cell() == cell);
                REQUIRE(std::equal(vec1.begin(), vec1.end(), char_list.begin()));
                Dop_table_characteristics dop = {"heal", 5, 2, 0, char_list_dop};
                

                item::Weapon weapon =  item::Weapon{"New weapon", 1, 8, 2, type_charasteristic::Strength};
                player.equip(dynamic_cast<item::Item*>(new item::Weapon{weapon}));

                REQUIRE(player.get_weapen() == weapon);

                item::Potion *potion = new item::Potion{"New potion", 1, &dop};

                REQUIRE(player.use_item(potion));
                REQUIRE(player.get_characteristics() == (Characteristics_table{char_list}  += dop));
                



    }
}
using namespace std;
namespace creature{
    TEST_CASE("Item") {
        item::Item* item = new item::Item{"item", 1, "lol"};
        creature::Creature creature{};
        string a ="ff";
        REQUIRE(item->get_name() == "item");
        REQUIRE(item->get_value() == 1);
        REQUIRE(item->get_description() == "lol");
        item::Item* item2 = new item::Item{"item2"};
        REQUIRE(item2->get_value() == 1);
        REQUIRE_THROWS(item::Item{""});
        REQUIRE_THROWS(item::Item{"v", -2});
        REQUIRE_THROWS(item->Puted(creature));
        REQUIRE_THROWS(item->Removed(creature));
        item->set_description(a);
        REQUIRE(item->get_description() == a);
        item->set_name(a);
        REQUIRE(item->get_name() == a);
        item->set_value(2);
        REQUIRE(item->get_value() == 2);
}
        TEST_CASE("Potion") {
                item::Potion* potion = new item::Potion{"Potion", 1,  nullptr};
                REQUIRE(potion->get_name() == "Potion");
                REQUIRE(potion->get_value() == 1);
                REQUIRE(potion->get_description() == "");
                item::Potion* potion0 = new item::Potion{};
                potion++;
                REQUIRE(potion0->get_name() == "Potion");
                REQUIRE(potion0->get_value() == 1);
                REQUIRE(potion0->get_description() == "A potion that heals the target.");
                REQUIRE(potion->get_value() == 5);
                potion--;
                REQUIRE(potion->get_value() == 1);
        }
        TEST_CASE("Master_keys") {
                item::Master_keys* master_key = new item::Master_keys{"Master_key", 2};
                REQUIRE(master_key->get_name() == "Master_key");
                REQUIRE(master_key->get_value() == 2);
                creature::Player* creatureq = new creature::Player{};
                REQUIRE(master_key->get_description() == "");
                item::Master_keys* master_key0 = new item::Master_keys{};
                *master_key += *master_key0;
                REQUIRE(master_key0->get_name() == "My master keys");
                REQUIRE(master_key0->get_value() == 1);
                REQUIRE(master_key0->get_description() == "");
                REQUIRE(master_key->get_value() == 3);
                item::Master_keys master_key3=  *master_key + *master_key0;
                REQUIRE(master_key3.get_value() == 4);
                item::Master_keys master_key4=  *master_key - *master_key0;                
                REQUIRE(master_key4.get_value() == 0);
                master_key->use(creatureq);
                REQUIRE(master_key0->get_value() == 1);
                Creature * creat = new creature::Creature{};
                REQUIRE_NOTHROW(master_key3.Puted(*creat));
                REQUIRE_NOTHROW(master_key3.Removed(*creat));

        }
        
        TEST_CASE("Openned") {
                std::vector<Charasteristic> char_list = {
                        {type_charasteristic::Strength, 8},
                        {type_charasteristic::Constitution, 8},
                        {type_charasteristic::Dexterity, 8},
                        {type_charasteristic::Intelligence, 8},
                        {type_charasteristic::Wisdom, 8},
                        {type_charasteristic::Charisma, 8}
                };
                Characteristics_table table(char_list);
                Creature * creat = new creature::Creature{};
                string name = "test";
                item::Chest * chest1 = new item::Chest{name,2 };
                item::Chest * chest3 = new item::Chest{name, name, 1 };
                item::Chest * chest = new item::Chest{new item::Master_keys{2}};

                REQUIRE(chest->get_name() == "Chest");
                REQUIRE(chest->get_value() == 1);
                REQUIRE(chest->get_description() == "");
                REQUIRE(chest->get_is_open() == 0);
                REQUIRE_NOTHROW(chest->set_is_open(0));
                REQUIRE_NOTHROW(chest->set_name(name));
                REQUIRE_NOTHROW(chest->set_value(2));
                REQUIRE_NOTHROW(chest->set_description(name));
                REQUIRE(chest->get_name() == "test");
                REQUIRE(chest->get_value() == 2);
                REQUIRE(chest->get_description() == "test");
                REQUIRE(chest->get_is_open() == 0);
                REQUIRE(chest->get_items()->get_value() == 2);
                REQUIRE_NOTHROW((chest->take_items())->get_value() == 2);
                REQUIRE_NOTHROW(chest->Puted(*creat));
                REQUIRE_NOTHROW(chest->Removed(*creat));
                REQUIRE(true == chest->openned(table));
                REQUIRE(chest->get_is_open() == 1);
                chest->close();
                REQUIRE(chest->get_is_open() == 0);
                delete chest;
        }
                


                

}