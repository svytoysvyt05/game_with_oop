 #include "dang/dang.hpp"

 int main() {

       
        dang::dang dang{};
        dang.start_game();
       return 0;
 }