#include "one.hpp"
#include "../creater/creater.hpp"

namespace item{
        void Potion::use(creature::Player* target){
                if(dop_table){
                        target->add_table(*dop_table);
                        (*target)+= dop_table->get_dop_HP();

                }else throw std::runtime_error("dop_table is null");
        }

        void Master_keys::use(creature::Player* target){
                if(value>0)value--;
                else throw std::runtime_error("невозможно");
        }

        void Master_keys::Removed(creature::Creature* person) {
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1){
                        person1->set_master_keys(person1->get_master_keys() - *this);
                }
        }
        void Master_keys::Puted(creature::Creature* person) {
                creature::Player* person1 = dynamic_cast<creature::Player*>(person);
                if(person1){
                        person1->set_master_keys(person1->get_master_keys() + *this);
                }
        }
}