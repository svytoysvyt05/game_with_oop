#ifndef ONE_H
#define ONE_H
#include "../item/item.hpp"
#include "../characteristics/characteristics.hpp"
#include <string>

namespace creature{
class Creature;
class Player;
}
namespace item{

class IUse{
        public:
        virtual void use(creature::Player* target) = 0;
};
/**
 * @brief  A class representing a one item.
 * 
 */
class Potion: public Item, public IUse{

        private:
        creature::Dop_table_characteristics* dop_table = nullptr;
        public:
        /**
         * @brief Construct a new Potion object
         * 
         */
        Potion(): Item("Potion", 1, "A potion that heals the target."){
                dop_table = new creature::Dop_table_characteristics{};
        }
        /**
         * @brief Construct a new Potion object
         * 
         * @param name 
         * @param value 
         * @param dop_table 
         * @param description 
         */
        Potion(const std::string& name, int value, creature::Dop_table_characteristics* dop_table, std::string description = ""):
        Item(name, value, description){
                if(dop_table)this->dop_table = dop_table;
                else dop_table = new creature::Dop_table_characteristics{};
        }
        /**
         * @brief Get the dop table object
         * 
         * @return creature::Dop_table_characteristics 
         */
        creature::Dop_table_characteristics get_dop_table() const {return *dop_table;};
        /**
         * @brief Set the Dop table object
         * 
         * @param dop_table 
         */
        void set_Dop_table (creature::Dop_table_characteristics* dop_table){
                this->dop_table = dop_table;
        }
        /**
         * @brief use potion
         * 
         * @param target 
         */
        void use(creature::Player* target) override;
        /**
         * @brief --
         * 
         * @return int 
         */
        int operator--(int){
                value--;
                if(value > 0){
                        return value;
                }
                return 0;
        }
        /**
         * @brief ++
         * 
         * @return int 
         */
        int operator++(int){
                return ++value;
        }

        Potion* clone() const override{
                return new Potion(*this);
        }
};
/**
 * @brief Master_keys
 * 
 */
class Master_keys: public Item, public IUse{
        public:
        /**
         * @brief Construct a new Master_keys object
         * 
         */
        Master_keys(): Item("My master keys", 1){}
        /**
         * @brief Construct a new Master_keys object
         * 
         * @param value 
         */
        Master_keys(int value): Master_keys(){
                if(value >= 0){
                        this->value = value;
                } else throw std::invalid_argument("Value must be greater than 0");
        }
        /**
         * @brief Construct a new Master_keys object
         * 
         * @param name 
         * @param value 
         * @param description 
         */
        Master_keys(const std::string& name, int value, const std::string& description = ""): Master_keys(value){
                if(!name.empty()){
                         this->name = name;
                         this->description = description;
                } else throw std::invalid_argument("Name must not be empty");
        }
        /**
         * @brief Get the value object
         * 
         * @return int 
         */
        int get_value() const {return value;}
        /**
         * @brief Get the name object
         * 
         * @return std::string 
         */
        std::string get_name() const {return name;}
        /**
         * @brief Set the value object
         * 
         * @param value 
         */
        void set_value(int value) {
                if(value > 0){
                        this->value = value;
                }
        }
        /**
         * @brief Set the name object
         * 
         * @param name 
         */
        void set_name(std::string &name) {
                if(!name.empty()){
                        this->name = name;               
                }
        }
        /**
         * @brief use keys
         * 
         * @param target 
         */
        void use(creature::Player* target) override;

/**
 * @brief +=
 * 
 * @param keys 
 * @return Master_keys& 
 */
        Master_keys& operator+=(const Master_keys& keys){
                value += keys.value;
                return *this;
        }

        Master_keys& operator+=(int val){
                value += val;
                return *this;
        }
        /**
         * @brief +
         * 
         * @param keys 
         * @return Master_keys 
         */
        Master_keys operator+(const Master_keys& keys){
                Master_keys new_keys(name, value + keys.value);
                return new_keys;
        }
        /**
         * @brief -
         * 
         * @param keys 
         * @return Master_keys 
         */
        Master_keys operator-(const Master_keys& keys){
                Master_keys new_keys(name,std::min(0, value + keys.value));
                return new_keys;
        }
        /**
         * @brief Removed
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override;

/**
 * @brief Puted
 * 
 * @param person 
 */
        void Puted(creature::Creature* person) override;

        Master_keys* clone() const override{
                return new Master_keys(*this);
        }
};

}
#endif // DANG_H