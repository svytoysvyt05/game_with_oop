#include "creater.hpp"
#include "../characteristics/characteristics.hpp"
#include <algorithm>
#include "../openned/openned.hpp"
#include <../cell/cell.hpp>
#include <iostream>

namespace creature{

        Creature::Creature(){
                name = "name1";
                HP = 9;
                characteristics = new Characteristics_table{};
                armor_class = 10;
                x_position = 0;
                y_position = 0;
                cell = nullptr;

        }
        Creature::Creature(const std::string& name1, int armor_class1, int HP1, std::string feature1, Characteristics_table* characteristics1, cell::Cell *cell, int x_position, int y_position): Creature(){
                if(!(HP1<0 || armor_class1<0 || name1.empty() || characteristics1==nullptr || (int) characteristics1->get_characteristics_table().size() != 6 || (int) characteristics1->get_characteristics_table().capacity() != 6)){
                        name = name1;
                        delete characteristics;
                        characteristics = characteristics1;
                        HP = std::min(HP1, characteristics->get_max_HP());
                        this->feature = feature1;
                        armor_class = std::max(armor_class1, 10+ characteristics->modifier(type_charasteristic::Dexterity));
                        this->x_position = x_position;
                        this->y_position = y_position;
                        this->cell = cell;
                }

        }

        void Creature::set_name(const std::string& name1){
                if(!name1.empty()) name = name1;
        }
        void Creature::set_HP(int HP1){
                if(HP1>=0) HP = HP1;
        }
        void Creature::set_armor_class(int armor_class1){
                if(armor_class>=0) armor_class = armor_class1;
        }
        int Creature::get_armor_class()const{
                return armor_class;
        }
        void Creature::set_characteristics(Characteristics_table* characteristics1){
                if(characteristics1==nullptr || characteristics1->get_characteristics_table().size() == 6 || characteristics1->get_characteristics_table().capacity() == 6)
                        characteristics = characteristics1;
        }
        std::string Creature::get_name() const{
                return name;
        }
        int Creature::get_HP()const{
                return HP;
        }

        void Creature::new_feature(std::string feature1){
                set_feature(feature1);               
        }
        void Creature::move(dang::Matrix<cell::Cell>& map, direction dir){
                if(speed_now < characteristics->get_speed()){
                        int idir = static_cast<int>(dir); 
                        int n_x = x_position + (((idir+1)%2) * abs(( idir/2)));
                        int n_y = y_position + ((idir%2) * abs(idir));
                        if(n_x >=0 && n_x < map.cols() && n_y >=0 && n_y < map.rows() && !map[n_y][n_x].get_creture() && 
                        static_cast<int>(map[n_y][n_x].get_type()) < 5){
                                speed_now++;
                                map[n_y][n_x].set_creture(map[y_position][x_position].get_creture());
                                map[y_position][x_position].set_creture(nullptr);
                                x_position = n_x;
                                y_position = n_y;
                                cell = &map[y_position][x_position];
                        } else throw std::runtime_error("you can't move in this direction");
                } else throw std::runtime_error(" you can't move now");
        }
        void Enemy::attack(Creature* target) {
                if(target != nullptr && std::abs(target->get_X_pos() - get_X_pos()) <= weapen->get_distance() && std::abs(target->get_Y_pos() - get_Y_pos()) <= weapen->get_distance()){
                        if(weapen->attack(*characteristics) >= target->get_armor_class()){
                                *target -= weapen->damage(*characteristics, target->get_feature());
                        }
                }
        }
        Enemy::~Enemy(){
                if(HP>0) dead();
        }

        Player::Player(const std::string &name, int level, int armor_class, int HP, std::string feature,
         Characteristics_table *characteristics, cell::Cell *cell, int x_position, int y_position,
          item::Weapon* weapen, item::Master_keys master_keys, int max_potion, std::vector<item::Potion> potions,
           std::vector<item::Protect*> protects, std::vector<Dop_table_characteristics> dop_tables):  Creature(name, armor_class, HP,  feature, characteristics, cell, x_position, y_position){
                if(max_potion<0 || level <0){
                        throw std::invalid_argument("mistake characteristics");
                }else{
                        this->weapen = weapen;
                        this->master_keys = master_keys;
                        this->max_potion = max_potion;
                        this->potions = potions;
                        this->protects = protects;
                        this->dop_tables = dop_tables;
                        this->level = level;
                }
        }
        void Player::add_table(Dop_table_characteristics& dop_table){
                if(std::find_if(dop_tables.begin(), dop_tables.end(), [dop_table](Dop_table_characteristics a){return a.get_name() == dop_table.get_name();}) != dop_tables.end()){
                        this->minus_table(dop_table);
                } 
                Characteristics_table a = *characteristics;
                std::vector<Charasteristic> characteristics1 = dop_table.get_dop_characteristics();
                std::for_each(characteristics1.begin(), characteristics1.end(),
                [&a](Charasteristic& dop_characteristic) {
                        dop_characteristic.set_value(std::min(dop_characteristic.get_value(), 20 - a.get_characteristic(dop_characteristic.get_type())->get_value()));
                });
                dop_table.set_dop_characteristics(characteristics1);
                dop_tables.push_back(dop_table);
                (*characteristics) += dop_table;
                HP += dop_table.get_dop_HP();
        }
        void Player::minus_table(Dop_table_characteristics& dop_table){
                if(std::find_if(dop_tables.begin(), dop_tables.end(), [dop_table](Dop_table_characteristics a){return a.get_name() == dop_table.get_name();}) == dop_tables.end()) throw std::runtime_error("такой таблицы нет");
                dop_tables.erase(std::remove_if(dop_tables.begin(), dop_tables.end(), [dop_table](Dop_table_characteristics a){return a.get_name() == dop_table.get_name();}), dop_tables.end());
                (*characteristics) -= dop_table;
                HP = std::min( HP,characteristics->get_max_HP());
        }
        void Player::set_dop_tables(std::vector<Dop_table_characteristics> dop_tables){
                std::for_each(dop_tables.begin(), dop_tables.end(),
                 [this](Dop_table_characteristics& dop_table) { minus_table(dop_table); });
                std::for_each(dop_tables.begin(), dop_tables.end(),
                 [this](Dop_table_characteristics& dop_table) { add_table(dop_table); });

        }
        void Player::attack(Creature* target){
                if(target != nullptr && std::abs(target->get_X_pos() - get_X_pos()) <= weapen->get_distance() &&
                 std::abs(target->get_Y_pos() - get_Y_pos()) <= weapen->get_distance()){
                        if(weapen->attack(*characteristics) > target->get_armor_class()){
                                if(dynamic_cast<Enemy*>( target) != nullptr){
                                        Enemy* target1 =  dynamic_cast<Enemy*>( target);
                                        if (dynamic_cast <item::Magic_Weapon*>(weapen) != nullptr){
                                                item::Magic_Weapon * magic_weapen = dynamic_cast <item::Magic_Weapon*>(weapen);
                                                (*target1) -= magic_weapen->damage(*characteristics, target->get_feature());
                                        } else if( dynamic_cast <item::Artefact_Magic_Weapon*>(weapen) != nullptr){
                                                item::Artefact_Magic_Weapon * magic_weapen = dynamic_cast <item::Artefact_Magic_Weapon*>(weapen);
                                                (*target1) -= magic_weapen->damage(*characteristics, target->get_feature());
                                        } else{
                                                (*target1) -= weapen->damage(*characteristics, target->get_feature());
                                        }
                                        if(target1->get_HP()<=0) XP += target1->get_XP();
                                }else (*target) -= weapen->damage(*characteristics, target->get_feature());  

                        }
                }else throw std::invalid_argument("you are too far from the target or target is not a creature");
        }
         void Creature::dead(){
                delete characteristics;
                HP = 0;
                cell->set_creture(nullptr);
                cell = nullptr;

        }
        bool Player::equip(item::Item* item1){
                if(!item1) return false;
                if(dynamic_cast<item::Protect*>(item1) != nullptr){
                        if (dynamic_cast<item::Artefact_Protect*>(item1) != nullptr)
                        {
                                item::Artefact_Protect *a = dynamic_cast<item::Artefact_Protect*>(item1);
                                Put_E(a);                               
                        }else{
                                item::Protect *a = dynamic_cast<item::Protect*>(item1);
                                Put_E(a);
                        }
                        
                }else if (dynamic_cast<item::Weapon*>(item1) != nullptr) {
                        if(dynamic_cast<item::Artefact_Weapon*>(item1)){
                                item::Artefact_Weapon *a = dynamic_cast<item::Artefact_Weapon*>(item1);
                                Put_W(a);
                        }else if (dynamic_cast<item::Magic_Weapon*>(item1)) {
                                item::Magic_Weapon *a = dynamic_cast<item::Magic_Weapon*>(item1);
                                Put_W(a);
                        }else if (dynamic_cast<item::Artefact_Magic_Weapon*>(item1)) {
                                item::Artefact_Magic_Weapon *a = dynamic_cast<item::Artefact_Magic_Weapon*>(item1);
                                Put_W(a);
                        }else{
                                item::Weapon *a = dynamic_cast<item::Weapon*>(item1);
                                Put_W(a);
                        }                        
                }else if (dynamic_cast<item::Potion*>(item1) != nullptr) {
                        item::Potion *a = dynamic_cast<item::Potion*>(item1);
                        auto it = std::find_if(potions.begin(), potions.end(), [&](item::Potion& potion)
                         { return potion.get_name() == a->get_name();});
                        if( it != potions.end()){
                                it++;
                        }else{
                                if(max_potion ==(int) potions.size()) return false;
                                potions.push_back(*a);
                        }
                }else if (dynamic_cast<item::Chest*>(item1) != nullptr) {
                        return false;
                }else if (dynamic_cast<item::Master_keys*>(item1) != nullptr) {
                        item::Master_keys *a = dynamic_cast<item::Master_keys*>(item1);
                        master_keys += *a;
                }else return false;
                return true;
        }
        bool Player::use_item(item::Item* item1){
                if(!item1) return false;
                if(dynamic_cast<item::Protect*>(item1) != nullptr){
                        return false;
                        
                }else if (dynamic_cast<item::Weapon*>(item1) != nullptr) {
                        return false; 
                }else if (dynamic_cast<item::Potion*>(item1) != nullptr) {
                        item::Potion *a = dynamic_cast<item::Potion*>(item1);
                        (*a).use(this);

                }else if (dynamic_cast<item::Chest*>(item1) != nullptr) {
                        item::Chest *a = dynamic_cast<item::Chest*>(item1);
                        if(master_keys.get_value()>0){
                                master_keys.use(this);
                                (*a).openned(*characteristics);
                                if ((*a).get_is_open()){
                                        item::Item* newI = (*a).take_items();
                                        equip(newI);
                                } else return false;
                        } else return false;
                                                                   
                }else if (dynamic_cast<item::Master_keys*>(item1) != nullptr) {
                        return false;
                } else return false;
                return true;
        }                       

        
}