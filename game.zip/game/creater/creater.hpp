#ifndef CREATURES_HPP
#define CREATURES_HPP

#include "../characteristics/characteristics.hpp"
#include "../one/one.hpp"
#include "../level/level.hpp"
#include "../cell/cell.hpp"
#include "../equip/equip.hpp"
// #include <algorithm>
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>
namespace creature {

class Creature;
enum class direction{
        forward = -1,
        back = 1,
        right = 2,
        left = -2,
};

class IPutting_Removal_Weapon{
        public:
        virtual void Removal_W() = 0;
        virtual void Put_W(item::Weapon *weapen1) = 0;
};
class IAttack{
        public:
        virtual void attack(Creature* enemy) = 0;
        // virtual void damage(Creature* enemy) = 0;
};

class IPutting_Removal_Equip{
        public:
        virtual void Removal_E(item::type_protect) = 0;
        virtual void Put_E(item::Protect *protect1) = 0;
};

class IMove{
        public:
        virtual void move(dang::Matrix<cell::Cell>& map, direction dir) = 0;
};


class Creature : public IMove{
friend class Player;
friend class Enemy;
private:
        std::string name;
        int HP;
        int armor_class;
        int x_position;
        int y_position;
        int speed_now = 0;
        std::string feature;
        Characteristics_table* characteristics;
        cell::Cell *cell; 
public:
        Creature();
        Creature(const std::string& name, int armor_class, int HP, std::string feature,
         Characteristics_table* characteristics, cell::Cell *cell, int x_position, int y_position);
        virtual ~Creature(){
                if(HP>0) dead();
        }
        void set_name(const std::string& name);
        void set_HP(int HP);
        void set_armor_class(int armor_class);
        int get_armor_class() const;
        int get_X_pos() const{
                return x_position;
        }
        virtual void tic(){
                speed_now = 0;
        }
        int get_Y_pos() const{
                return y_position;
        }
        void set_X_pos(int x_position){
                if(x_position>=0) this->x_position = x_position;
                else throw std::invalid_argument("Position can't be less than 0");
        }
        void set_Y_pos(int y_position){
                if(y_position>=0) this->y_position = y_position;
                else throw std::invalid_argument("Position can't be less than 0");
        }
        void set_characteristics(Characteristics_table* characteristics);
        std::string get_name() const;
        int get_HP() const;
        std::string get_feature() const{
                return feature;
        }
        void set_feature(std::string feature){
                this->feature = feature;
        }
        void set_speed_now(int speed_now){
                if(speed_now >=0) this->speed_now = speed_now;
                throw std::invalid_argument("Speed can't be less than 0");
        }
        int get_speed_now() const{
                return speed_now;
        }
        void set_cell(cell::Cell *cell){
                this->cell = cell;
        }
        cell::Cell *get_cell() const{
                return cell;
        }
        Characteristics_table& get_characteristics() const{
                return *characteristics;
        }
        void new_feature(std::string feature);
        void move(dang::Matrix<cell::Cell>& map, direction dir) override;
        virtual void dead();
        int operator-=(int HP1){
                this->HP-=HP1;
                if(HP<=0){
                        HP = 0;
                        this->dead();
                }
                return HP;
        }
        int operator+=(int HP1){
                this->HP+=HP1;
                if(HP > characteristics->get_max_HP()){
                        HP = characteristics->get_max_HP();
                }
                return HP;
        }
};
        
class Enemy : public Creature, public IAttack{
        private:
        item::Weapon* weapen{};
        item::Item* item = nullptr;
        int XP =100;
        public:
        Enemy() : Creature() {};
        Enemy(const std::string &name, int armor_class, int HP, std::string feature,
         Characteristics_table *characteristics, cell::Cell *cell, int x_position, int y_position, item::Weapon* weapen, item::Item* item):
         Creature(name, armor_class, HP,  feature, characteristics, cell, x_position, y_position){
                if(weapen)this->weapen = weapen;
                this->item = item;
        }
        ~Enemy();
        void dead() override{
                delete characteristics;
                delete weapen;
                if(cell){
                        if(item){
                                get_cell()->set_item(item);
                                item = nullptr;
                        }
                        cell->set_creture(nullptr);
                }
        }
        void set_item(item::Item* item){
                this->item = item;
        }
        item::Weapon* get_wapen() const{
                return this->weapen;
        }
        item::Item* get_item() const{
                return item;
        }
        void set_XP(int XP){
                if (XP>0)this->XP = XP;
                throw std::invalid_argument("XP must be greater than 0");
        }
        int get_XP() const{
                return XP;
        }
        void attack(Creature* target) override;
        
        void set_weapen(item::Weapon* weapen ){
                if(this->weapen)delete this->weapen;
                if(weapen != nullptr) this->weapen = weapen;
                else weapen = new item::Weapon{};
        }
        item::Weapon& get_weapen() const{ return *weapen ;}

};

class Player : public IPutting_Removal_Equip, public IPutting_Removal_Weapon, public IAttack, public Creature{
        private:
        item::Weapon* weapen = new item::Weapon{};
        int XP = 0;
        item::Master_keys master_keys{3};
        int level = 1;
        int max_potion = 10;
        std::vector<item::Potion> potions;
        std::vector<item::Protect*> protects;
        std::vector<Dop_table_characteristics> dop_tables;

        public:

        Player(): Creature() {};
        Player(const std::string &name, Characteristics_table *characteristics, std ::string feature, cell::Cell *cell, int x_position, int y_position):
        Creature(name, 10 + characteristics->get_characteristics_table()[2].modifier(), characteristics->get_max_HP(), feature, characteristics, cell, x_position, y_position){}

        Player(const std::string &name, int level, int armor_class, int HP, std::string feature,
         Characteristics_table *characteristics, cell::Cell *cell, int x_position, int y_position, item::Weapon* weapen,
         item::Master_keys master_keys, int max_potion, std::vector<item::Potion> potions,
          std::vector<item::Protect*> protects, std::vector<Dop_table_characteristics> dop_tables);
        ~Player(){
                if(HP>0) dead();
                
        }
        void dead() override{
                delete characteristics;
                HP = 0;
                if(cell) cell->set_creture(nullptr);
                cell = nullptr;
                delete weapen;
        }
        void set_max_potion(int max_potion){
                if (max_potion>0) this->max_potion = max_potion;
                throw std::invalid_argument("max_potion must be greater than 0");
        }
        void set_Potions(std::vector<item::Potion> Potions){
                if (((int) Potions.size())<=max_potion) this->potions = Potions;
                throw std::invalid_argument("Potions must be less than or equal to max_potion");
        }
        void set_dop_tables(std::vector<Dop_table_characteristics> dop_tables);
        void set_XP(int XP){
                if (XP>0) this->XP = XP;
                throw std::invalid_argument("XP must be greater than 0");
        }
        void set_master_keys(item::Master_keys master_keys){
                this->master_keys = master_keys;
        }
        void set_characteristic(type_charasteristic type, int value, int skill = 0, int save = 0){
                characteristics->set_characteristic(type, value, skill, save);
        }
        int get_XP() const{
                return XP;
        }
        std::vector<item::Potion> get_potions() const{ return potions; }
        int get_max_potion() const{
                return max_potion;
        }
        item::Master_keys get_master_keys() const{
                return master_keys;
        }
        int get_level() const{ return level;}
        void set_level(int level){ 
                if(level >0) this->level = level;
                else throw std::invalid_argument("level must be greater than 0");
        }
        void set_weapen(item::Weapon* weapen ){
                if(this->weapen)delete this->weapen;
                if(weapen != nullptr) this->weapen = weapen;
                else weapen = new item::Weapon{};
        }
        item::Weapon& get_weapen() const{ return *weapen ;}
        bool equip(item::Item* item);
        void level_up(){
                if (XP>=level *300){
                        level++;
                        XP -= level * 300;
                        characteristics->level_up();
                        HP += 10;
                }
        }
        bool use_item(item::Item* item);
        void use_my_potion(int potion_number){
                if (potion_number>0 && potion_number<=((int)potions.size())){
                        item::Potion potion = potions[potion_number-1];
                        potion.use(this);
                        potion--;
                        potions[potion_number-1]--;
                        if(!potion.get_value())
                                potions.erase(potions.begin()+potion_number-1);

                }
        }
        void minus_table(Dop_table_characteristics& dop_table);
        void add_table(Dop_table_characteristics& dop_table);
        
        void Removal_W() override{
                if(!weapen) throw std::runtime_error("no weapen");
                if( dynamic_cast <item::Artefact_Weapon*>(weapen)!=nullptr){
                        item::Artefact_Weapon * artefact = dynamic_cast<item::Artefact_Weapon*>(weapen);
                        artefact->Removed(this);
                }else if( dynamic_cast <item::Artefact_Magic_Weapon*>(weapen)!=nullptr){
                        item::Artefact_Magic_Weapon * artefact = dynamic_cast <item::Artefact_Magic_Weapon*>(weapen);
                        artefact->Removed(this);
                } 
                delete weapen;
        }
        void Put_W(item::Weapon *weapen1) override{
                if(weapen) Removal_W();
                if(!weapen1) weapen1 = new item::Weapon{};
                weapen = weapen1;                
                if( dynamic_cast <item::Artefact_Weapon*>(weapen)!=nullptr){
                        item::Artefact_Weapon * artefact = dynamic_cast<item::Artefact_Weapon*>(weapen);
                        artefact->Puted(this);
                }else if( dynamic_cast <item::Artefact_Magic_Weapon*>(weapen)!=nullptr){
                        item::Artefact_Magic_Weapon * artefact = dynamic_cast <item::Artefact_Magic_Weapon*>(weapen);
                        artefact->Puted(this);
                } 
        }
        void Removal_E(item::type_protect type) override{
                auto iter =  std::find_if(protects.begin(), protects.end(),
                [type](item::Protect* protect){return (int) protect->get_type() == (int) type;});
                if(iter == protects.end()) throw std::invalid_argument("mistake type");
                if( dynamic_cast <item::Artefact_Protect*>(*iter)!=nullptr){
                        item::Artefact_Protect * artefact = dynamic_cast<item::Artefact_Protect*>(*iter);
                        artefact->Removed(this);
                }
                protects.erase(iter);

        }
        void Put_E(item::Protect *protect1) override{
                item::type_protect type = protect1->get_type();
                auto iter =  std::find_if(protects.begin(), protects.end(),
                [type](item::Protect* protect){return (int) protect->get_type() == (int) type;});
                if(iter != protects.end()) Removal_E((*iter)->get_type());                
                if( dynamic_cast <item::Artefact_Protect*>(*iter)!=nullptr){
                        item::Artefact_Protect * artefact = dynamic_cast<item::Artefact_Protect*>(*iter);
                        artefact->Puted(this);
                }
                protects.push_back(protect1);              
        }
        void attack(Creature* target) override;
        void tic() override{
                speed_now =0;
                std::vector<Dop_table_characteristics> s;
                std::for_each( dop_tables.begin(), dop_tables.end(), [&s]( Dop_table_characteristics& dop){
                        if(dop.get_move()<=1) s.push_back(dop);
                        dop--;
                });
                if(!s.empty()){
                        for( auto& str : s) minus_table( str);
                }
                level_up();
        }
};

}


#endif // CREATER_HPP
