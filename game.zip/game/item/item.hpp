#ifndef ITEM_H
#define ITEM_H
// #include <iostream>
// #include <vector>
#include <stdexcept>
#include <string>
// #include <algorithm>
// #include <memory>
namespace creature{
class Creature;
}
namespace item{

class IPutted_Removed{
        public:
        virtual void Removed(creature::Creature* person) = 0;
        virtual void Puted(creature::Creature* person) = 0;
};

class Item : public IPutted_Removed{
        protected:
        std::string name= "Item";
        int value = 1;
        std::string description = "";

        public:
        /**
         * @brief Destroy the Item object
         * 
         */
        virtual ~Item() = default;
        /**
         * @brief Construct a new Item object
         * 
         */
        Item() = default;

        virtual Item* clone() const{
                return new Item(*this);
        }

        Item(const std::string& name, int value, const std::string& description  = ""){
                if(name.empty() || value < 0){
                        throw std::invalid_argument("Invalid arguments");
                } else{
                        this->name = name;
                        this->value = value;
                        this->description = description;
                }
        }

        Item(const std::string& name){
                if(name.empty()){
                        throw std::invalid_argument("Invalid arguments");
                } else{
                        this->name = name;
                }
        }
        /**
         * @brief Removed
         * 
         * @param person 
         */
        void Removed(creature::Creature* person) override{
                throw std::runtime_error("Item::Removed() - Not implemented");
        }
        /**
         * @brief Puted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override{
                throw std::runtime_error("Item::Puted() - Not implemented");
        }
        /**
         * @brief Get the name object
         * 
         * @return std::string 
         */
        std::string get_name() const {return name;}
        /**
         * @brief Set the name object
         * 
         * @param name 
         */
        void set_name(const std::string &name) {
                if(name.empty()){
                        throw std::invalid_argument("Invalid arguments");
                } else{
                        this->name = name;
                }
        }
        /**
         * @brief Get the value object
         * 
         * @return int 
         */

        int get_value() const {return value ;}

        /**
         * @brief Set the value object
         * 
         * @param value 
         */
        void set_value(int value) {
                if(value>=0) this->value = value ;
                else throw std::invalid_argument("Invalid arguments");
        }
        /**
         * @brief Get the description object
         * 
         * @return std::string 
         */
        std::string get_description() const {return description;}

        /**
         * @brief Set the description object
         * 
         * @param description 
         */
        void set_description(const std::string &description) {this->description = description;}

};

}
#endif // DANG_Ha