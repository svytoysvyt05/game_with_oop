#ifndef DANG_H
#define DANG_H
#include "../creater/creater.hpp"
#include <iostream>
#include <ncurses.h>
#include <mutex>
#include <barrier>
#include <shared_mutex>
namespace dang {

class dang
{
        private:
        int move = 1;
        std::shared_mutex map_mutex;
        int level_map =1;
        Matrix<cell::Cell> *map = nullptr;
        creature::Player *player;
        std::vector<creature::Creature*> initiaitive;

        public:
        dang( creature::Player *player, Matrix<cell::Cell>* map){
                this->player = player;
                this->map = map;
        }
        dang(){
                this->player = nullptr;
                this->map = nullptr;
        }
        ~dang(){
                if (this->player != nullptr){
                        delete this->player;
                }
                if (this->map != nullptr){
                        delete this->map;
                        }

        }
        void load_map();
        void print_player();
        void start_game();
        void end_game();
        void new_level(bool up);
        void move_player();
        void move_enemy(creature::Enemy* enemy);
        void move_person();
        void set_map(Matrix<cell::Cell>* new_map){
                map = new_map;
        }
        void set_map(int width, int height){
                if(map) delete map;
                map = new Matrix<cell::Cell>{width, height};
        }
        void set_player(creature::Player* new_player){
                this->player = new_player;
        }
        void draw_map();
        Matrix<cell::Cell>* get_map(){
                return map;
        }
        creature::Player* get_player(){
                return player;
        }
        std::vector<creature::Creature*> get_initiative(){
                return initiaitive;
        }
        void set_initiative(std::vector<creature::Creature*> new_initiative){
                initiaitive = new_initiative;
        }
        void add_initiative(creature::Creature* creature){
                initiaitive.push_back(creature);
        }
        void remove_initiative(creature::Creature* creature){
                for(auto it = initiaitive.begin(); it != initiaitive.end(); ++it){
                        if(*it == creature){
                                initiaitive.erase(it);
                                break;
                        }
                }
        }
        int get_level(){
                return level_map;
        }
        int get_move(){
                return move ;
        }
        void set_level(int new_level){
                level_map = new_level;
        }
        void set_move(int new_move){
                move = new_move;
        }
        


        };
        std::vector<creature::direction> findPath(const Matrix<cell::Cell>& matrix, std::pair<int, int> start, std::pair<int, int> end);
        int roll_char();


} // namespace dang

#endif