#include "dang.hpp"
#include "../characteristics/characteristics.hpp"
#include "../openned/openned.hpp"
#include "../view/view.hpp"
#include "creater.hpp"
#include <map>
#include <queue>
#include <utility>
#include <string>
#include <vector>
#include <sstream>
#include <iterator>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <fstream>
#include <random>
#include <unordered_set>

using std::vector;
using std::string;
using std::cin;

namespace dang{
void removeback(std::string& str, const std::string& characters) {
    std::unordered_set<char> charSet(characters.begin(), characters.end());

    // Удаляем символы с конца строки, пока они находятся в заданном наборе символов
    while (!str.empty() && charSet.count(str.back())) {
        str.pop_back();
    }
}
void creature_map_item(std::fstream &item, std::map<string, item::Item*> *items, std::map<string, item::Enchanted>  enchanteds){
        int type;
        while(item >> type){
                int min_damage, max_damage, distance, type_c;
                string name, description, enchanteds_s;
                int value, max_HP, speed, move, dop_armor, type_armor;
                int charac[6][3]; 
                vector<creature::Charasteristic> vector;
                std::istringstream stream1;
                std::vector<std::string> enchanteds_vec;
                std::vector<item::Enchanted> enchanteds_vec1;
                switch (type){
                case 1:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        item >> min_damage >> max_damage >> distance >> type_c;
                        // std::cout<< name<< std::endl;
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Weapon(name, description, min_damage, max_damage, distance, static_cast<creature::type_charasteristic>(type_c)));
                        break;
                case 2:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");

                        item >> value;
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Master_keys(name, value, description));
                        break;
                case 3:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        item >> dop_armor >> type_armor;
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Protect(name, dop_armor, static_cast<item::type_protect>(type_armor), description));
                        break;
                case 4:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        item >> value>> max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), charac[i][0], charac[i][1], charac[i][2]});
                        }
                        item >> move;
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Potion(name, value, new creature::Dop_table_characteristics{name, max_HP, move, speed,
                        vector} , description));

                        break;
                case 5:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        std::getline(item, enchanteds_s);
                        removeback(enchanteds_s, "\r ");
                        std::transform(enchanteds_s.begin(), enchanteds_s.end(), enchanteds_s.begin(),
                        [](unsigned char c){ return std::tolower(c); });
                        stream1.str(enchanteds_s);


                        // Разделяем строку на слова и сохраняем их в вектор
                        std::copy(std::istream_iterator<std::string>(stream1),
                                std::istream_iterator<std::string>(),
                                std::back_inserter(enchanteds_vec));
                        item >> min_damage >> max_damage >> distance >> type_c;
                        for(string s : enchanteds_vec){ enchanteds_vec1.push_back(enchanteds[s]);}
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Magic_Weapon(name, description, min_damage, max_damage, distance, static_cast<creature::type_charasteristic>(type_c), enchanteds_vec1));
                        break;
                case 6:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        item >> min_damage >> max_damage >> distance >> type_c;
                        item >>  max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), charac[i][0], charac[i][1], charac[i][2]});
                        }
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Artefact_Weapon{name, description, min_damage, max_damage, distance,
                                static_cast<creature::type_charasteristic>(type_c), new creature::Dop_table_characteristics{ name, max_HP, 100000, speed, vector}});
                        break;
                case 7:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        std::getline(item, enchanteds_s);
                        removeback(enchanteds_s, "\r ");
                        stream1.str(enchanteds_s);
                        std::transform(enchanteds_s.begin(), enchanteds_s.end(), enchanteds_s.begin(),
                        [](unsigned char c){ return std::tolower(c); });
                        item >> min_damage >> max_damage >> distance >> type_c;
                        item >>  max_HP >> speed;
                        std::copy(std::istream_iterator<std::string>(stream1),
                                std::istream_iterator<std::string>(),
                                std::back_inserter(enchanteds_vec));
                        
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), charac[i][0], charac[i][1], charac[i][2]});
                        }
                        for(string s : enchanteds_vec){ enchanteds_vec1.push_back(enchanteds[s]);}
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Artefact_Magic_Weapon{name, description, min_damage, max_damage, distance,
                                static_cast<creature::type_charasteristic>(type_c), new creature::Dop_table_characteristics{ name, max_HP, 100000, speed, vector}, enchanteds_vec1});
                        break;
                case 8:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        removeback(name, "\r ");
                        std::getline(item, description);
                        removeback(description, "\r ");
                        item >> dop_armor >> type_armor;

                        item >> max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), charac[i][0], charac[i][1], charac[i][2]});
                        }
                        (*items)[name] = dynamic_cast<item::Item*>(new item::Artefact_Protect(name, dop_armor, static_cast<item::type_protect>(type_armor), new creature::Dop_table_characteristics{name, max_HP, 1000, speed, vector}, description));
                        break;

                default:
                        break;
                }
        }
}
int roll_char() {
    // Веса для чисел от 10 до 18
    std::vector<int> weights = {4, 5, 9, 8, 7, 6, 5, 4, 3, 2, 1}; // Чем меньше число, тем больше вес
    std::vector<int> numbers = {8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};

    // Генерация случайного числа
    std::random_device rd; // Получаем случайное число из аппаратного генератора
    std::mt19937 gen(rd()); // Инициализируем генератор
    std::discrete_distribution<> dist(weights.begin(), weights.end()); // Создаем дискретное распределение

    int index = dist(gen); // Генерируем индекс на основе весов
    return numbers[index]; // Возвращаем соответствующее число
}

int roll_comp() {
    // Веса для чисел от 10 до 18
    std::vector<int> weights = {10, 3, 3, 1, 1}; // Чем меньше число, тем больше вес
    std::vector<int> numbers = {0, 1, 2, 3, 4};

    // Генерация случайного числа
    std::random_device rd; // Получаем случайное число из аппаратного генератора
    std::mt19937 gen(rd()); // Инициализируем генератор
    std::discrete_distribution<> dist(weights.begin(), weights.end()); // Создаем дискретное распределение

    int index = dist(gen); // Генерируем индекс на основе весов
    return numbers[index]; // Возвращаем соответствующее число
}
void creature_map_enemy(std::fstream &enemy, std::map<string, item::Item*> items,std::map<std::string, creature::Enemy*> *enemies){
        string name, name_item, name_weapon, feature;
        int max_HP, speed, armor, XP;

        while( std::getline( enemy, name)){
                vector<creature::Charasteristic> vector;
                for(int i = 0; i < 6; i++){
                        vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), roll_char(), roll_comp(), roll_comp()});
                }                        
                enemy >>armor >> max_HP >> speed >> feature;
                enemy.ignore(100, '\n');
                std::getline( enemy, name_weapon);
                removeback(name_weapon, "\r ");
                removeback(name, "\r ");
                std::getline( enemy, name_item);
                removeback(name_item, "\r ");
                std::transform(feature.begin(), feature.end(), feature.begin(),
                [](unsigned char c){ return std::tolower(c); });
                enemy >> XP;
                (*enemies)[name] = new creature::Enemy{name, armor, max_HP/4, feature, new creature::Characteristics_table{vector, max_HP/4, speed}, nullptr, 0, 0, new item::Weapon{*dynamic_cast<item::Weapon*>(items[name_weapon])}, items[name_item]->clone()};
                enemy.ignore(100, '\n');
        }
                


}

void dang::end_game(){
        view::MapRenderer visualizer{map };
        visualizer.deinit();
        
        std::cout << "Game Over" << std::endl;
        if (this->player->get_HP()>0){
                std::cout << "You win !" << std::endl;
        } else  {
                std::cout << "You died lose!" << std::endl;
        }
}

void dang::new_level(bool down){
        Matrix<cell::Cell> *map_old;
        map_old = map;
        std::fstream levels;
        levels.open(("../files/level_" + std::to_string(level_map) + ".txt"));
        std::fstream enchanted;
        enchanted.open("../files/enchanted_" + std::to_string(level_map) + ".txt");
        std::fstream item;
        item.open("../files/item_" + std::to_string(level_map) + ".txt");
        std::fstream enemy;
        enemy.open("../files/enemy_" + std::to_string(level_map) + ".txt");
        if( levels.is_open() && enchanted.is_open() && item.is_open() && enemy.is_open()){
                std::string a;
                double b;
                std::map<string, item::Enchanted>  enchanteds;
                while(enchanted >> a >> b){
                        std::transform(a.begin(), a.end(), a.begin(),
                                [](unsigned char c){ return std::tolower(c); });
                        enchanteds[a] = item::Enchanted(a, b);
                }
                std::map<string, item::Item*> items;
                creature_map_item(item, &items, enchanteds);

                std::map<string, creature::Enemy*> enemies;
                creature_map_enemy( enemy, items,  &enemies);
                int weight, height;
                levels >> height >> weight;
                map = new Matrix<cell::Cell>{ height, weight};
                for( int i = 0; i < height; i++){
                        for( int j = 0; j < weight; j++){
                                int type = -1;
                                string name_enemy, name_item;
                                levels >> type;
                                (*map)[i][j].set_type(static_cast<cell::type_point>(type));
                                levels.ignore(100, '\n');
                                std::getline(levels, name_enemy);
                                removeback(name_enemy, "\r ");
                                if(name_enemy.size()){
                                        (*map)[i][j].set_creture(dynamic_cast<creature::Creature*> (enemies[name_enemy]));
                                        initiaitive.push_back(dynamic_cast<creature::Creature*> (enemies[name_enemy]));
                                        (*enemies[name_enemy]).set_cell(&(*map)[i][j]);
                                        (*enemies[name_enemy]).set_Y_pos(i);
                                        (*enemies[name_enemy]).set_X_pos(j);


                                }
                                std::getline(levels, name_item);
                                removeback(name_item, "\r ");

                                if(type == 6)
                                {
                                        (*map)[i][j].set_item(dynamic_cast<item::Item*>(new item::Chest{ items[name_item]->clone(), rand()%10 +5}));
                                }
                        }
                }
                levels.close();
                enchanted.close();
                item.close();
                enemy.close();
                int flag = 0;
                if (map_old && (*map)[player->get_Y_pos()][player->get_X_pos()].get_type() == static_cast<cell::type_point>(1+!down)
                  && map_old[player->get_Y_pos()][player->get_X_pos()]->get_type() == static_cast<cell::type_point>(1+down)){
                        player->set_cell(&(*map)[player->get_Y_pos()][player->get_X_pos()]);
                        (*map)[player->get_Y_pos()][player->get_X_pos()].set_creture(player);
                        flag = 1;
                }else{
                        for(int i = 0; i < map->rows()&&!flag; i++){
                                for(int j = 0; j < map->cols(); j++){
                                        if((*map)[i][j].get_type() == cell::type_point::stair_up){
                                                player->set_X_pos(j);
                                                player->set_Y_pos(i);
                                                player->set_cell(&(*map)[i][j]);
                                                player->set_weapen(new item::Weapon{*(dynamic_cast<item::Weapon*>(items["Hero's Blade"]))});
                                                (*map)[i][j].set_creture(player);
                                                flag = 1;
                                                break;
                                        }                                                
                                
                                }
                        }
                }
                for( auto i: items) delete i.second;
                if(!flag) throw std::runtime_error("Error: No stairs found");
        } else end_game();
}

void dang::load_map(){
        std::fstream levels;
        levels.open(("../files/level_" + std::to_string(level_map) + ".txt"));
        if( levels.is_open()){
                for( int i = 0; i < map->rows(); i++){
                        levels  <<"\n";
                        for( int j = 0; j < map->cols(); j++){
                                int type = -1;
                                string name_enemy = "", name_item = "";
                                if((*map)[i][j].get_item() && (*map)[i][j].get_type() != cell::type_point::chest
                                  && (dynamic_cast<const item::Chest *>((*map)[i][j].get_item()))->get_items()){
                                        name_item = (*map)[i][j].get_item()->get_name();
                                  }
                                if((*map)[i][j].get_creture() && nullptr !=
                                (dynamic_cast<const creature::Player *>((*map)[i][j].get_creture()))){
                                        name_item = (*map)[i][j].get_creture()->get_name();
                                  }
                                levels << type<<"\n" << name_enemy <<"\n"<< name_item;
                        }    
                }
        }        
}

void dang::start_game(){
        std::vector<creature::Charasteristic> vector;
        // int charac[6][3]; //запись характеристик из потока
        // for( int i = 0; i < 6; i++){
        //         for( int j = 0; j < 3; j++){
        //                 cin >> charac[i][j];
        //         }
        // }
        // for(int i = 0; i < 6; i++){
        //         vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), charac[i][0], charac[i][1], charac[i][2]});
        // }
        for(int i = 0; i < 6; i++){ // рандомизация характеристик 
                vector.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), roll_char(), roll_comp()+1, roll_comp()+1});
        } 
        string name = "Player", features = "humanoid";
        std::getline(cin, name);
        removeback(name, "\r ");
        std::istringstream stream1;

        player = new creature::Player{name, new creature::Characteristics_table{vector, 100},features, nullptr, 0, 0};
        
        
        new_level(1);
        std::sort(initiaitive.begin(), initiaitive.end(), [](const creature::Creature* a, const creature::Creature* b){
                return (*a).get_characteristics().modifier(creature::type_charasteristic::Dexterity) < (*b).get_characteristics().modifier(creature::type_charasteristic::Dexterity) ;
                });
        initiaitive.emplace(initiaitive.begin(), player);
        player->set_master_keys(player->get_master_keys() + item::Master_keys{1000}); //test

        move_person();
}

void dang::move_person(){
        while(!( player->get_HP() <=0 || !player->get_cell() || player->get_cell()->get_type() == cell::type_point::exit)){
                move_player();
                // if(player->get_cell()->get_type() == cell::type_point::exit) break;
                player->tic();   
                if( player->get_HP() <=0 || player->get_cell()->get_type() == cell::type_point::exit) break;

                
                std::vector<creature::Enemy*> enemies;
                enemies.reserve(initiaitive.size()-1);
                for ( auto creat: initiaitive){
                        if( dynamic_cast<creature::Enemy*>(creat) != nullptr){                              
                                creature::Enemy* enemy = dynamic_cast<creature::Enemy*>(creat);
                                if (enemy->get_HP() > 0) {
                                        enemies.push_back(enemy);
                                }
                        }
                }
                std::vector<std::thread> threads;
	auto num = std::thread::hardware_concurrency();
	if ( num == 0) num = 64;
	threads.reserve(num);
	int size =  enemies.size();
	for (int i = 0; i < num; i++) {
		int start = i * size / num;
		int end = std::min((int) ((1+i) * size / num), size);
		threads.emplace_back([this, enemies, start, end]() {
		for (int j = start; j < end; j++) {
			creature::Enemy* enemy = enemies[j];
			this->move_enemy(enemy);
			enemy->tic();
		}
	});
	}
                for (auto& t : threads) {
                        t.join();
                }
        
        }
        end_game();
}
void dang::move_player(){
        view::MapRenderer visualizer{ map };
        visualizer.render();
        int flag;
        while(5 == (flag = visualizer.move_player(player))){
                switch (flag){
                        case 1:
                                level_map++;
                                new_level(1);
                                break;
                        case -1:
                                if(level_map !=1){
                                        level_map--;
                                        new_level(0);
                                }
                                break;
                        case 5:
                                load_map();
                                map = nullptr;
                                new_level(1);
                                break;
                        default:
                                break;
                             
                }

        }
        visualizer.deinit();
}


std::vector<creature::direction> findPath(const Matrix<cell::Cell>& matrix, std::pair<int, int> start, std::pair<int, int> end) {
    int rows = matrix.rows();
    int cols = matrix.cols();

    std::vector<std::vector<bool>> visited(rows, std::vector<bool>(cols, false));
    std::vector<std::vector<std::pair<int, int>>> parent(rows, std::vector<std::pair<int, int>>(cols, {-1, -1}));

    // Направления движения и соответствующие им строки
    std::vector<std::pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    std::vector<creature::direction> dirNames = {creature::direction::forward, creature::direction::back, creature::direction::left, creature::direction::right};


    std::queue<std::pair<int, int>> q;
    q.push(start);
    visited[start.first][start.second] = true;

    while (!q.empty()) {
        auto [currX, currY] = q.front();
        q.pop();

        if (currX == end.first && currY == end.second) break; // Достигли конца

        for (size_t i = 0; i < directions.size(); i++) {
            int newX = currX + directions[i].first;
            int newY = currY + directions[i].second;

            if (newX >= 0 && newX < rows && newY >= 0 && newY < cols &&
                !visited[newX][newY] && static_cast<int>(matrix[newX][newY].get_type())<5 && !(dynamic_cast< creature::Enemy *>(matrix[newX][newY].get_creture()))) {
                visited[newX][newY] = true;
                parent[newX][newY] = {currX, currY};
                q.push({newX, newY});
            }
        }
    }

    // Восстановление пути
    std::vector<creature::direction> path;
    int currX = end.first;
    int currY = end.second;

    while (!(currX == start.first && currY == start.second)) {
        auto [prevX, prevY] = parent[currX][currY];

        if (prevX == -1 && prevY == -1) {
            return {}; // Путь не найден
        }

        for (size_t i = 0; i < directions.size(); i++) {
            if (prevX + directions[i].first == currX && prevY + directions[i].second == currY) {
                path.push_back(dirNames[i]);
                break;
            }
        }

        currX = prevX;
        currY = prevY;
    }

    reverse(path.begin(), path.end());
    return path;
}

void dang::move_enemy(creature::Enemy* enemy){
        int n_x_player = player->get_X_pos();
        int n_y_player = player->get_Y_pos();
        std::vector<creature::direction>  path;
        {
                std::shared_lock<std::shared_mutex> lock(map_mutex);
                path = findPath(*map, {enemy->get_Y_pos(), enemy->get_X_pos()},
                {n_y_player, n_x_player});
        }
        if (!path.empty()){
                for(int i = 0; i < std::min(static_cast<int>( path.size())-1, enemy->get_characteristics().get_speed()); i++){
                        if( abs(enemy->get_X_pos() - n_x_player) <= enemy->get_weapen().get_distance() &&
                        abs(enemy->get_Y_pos() - n_y_player) <= enemy->get_weapen().get_distance()){
                                break;
                        }
                        try{
                                std::lock_guard<std::shared_mutex> lock(map_mutex);
                                enemy->move(*map, path[i]);
                        } catch(...){
                                break;
                        } 
                }
        }
        if( abs(enemy->get_X_pos() - n_x_player) <= enemy->get_weapen().get_distance() &&
         abs(enemy->get_Y_pos() - n_y_player) <= enemy->get_weapen().get_distance()){
                std::lock_guard<std::shared_mutex> lock(map_mutex);
                enemy->attack(player);
         }

}




}
//sfml std::