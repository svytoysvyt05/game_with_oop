#ifndef LEVEL_H
#define LEVEL_H
#include <type_traits>
#include <fstream>
#include <cassert>
#include <cstddef> // Для int
#include <iterator> // Для std::random_access_iterator_tag
#include <memory>   // Для std::unique_ptr
#include <stdexcept> // Для выброса исключений при ошибках
#include <type_traits> // Для std::conditional_t
#include <cstddef>
#include <iterator>

namespace dang {



template <typename T>
struct Line
{

        T* cells;
};

template <std::default_initializable T>
class Matrix;

// Итератор для строки
template <typename T, bool is_const>
class OneIterator {
public:

/*!
   * @brief Тип, обозначающий дистанцию между двумя итераторами,
   *        т.е. результат std::distance(it1, it2)
   */
  typedef ptrdiff_t difference_type;

  /*!
   * @brief Адресуемый итератором тип
   */
  typedef T value_type;

  /*!
   * @brief Тип указателя на хранимое значение,
   *        для const_iterator - const T*, для обычного - T*
   */
  typedef std::conditional_t<is_const, const T, T>* pointer;

  /*!
   * @brief Тип ссылки на хранимое значение,
   *        для const_iterator - const T&, для обычного - T&
   */
  typedef std::conditional_t<is_const, const T, T>& reference;

  /*!
   * @brief Категория итератора
   */
  typedef std::random_access_iterator_tag iterator_category;

      ~OneIterator() = default;

    reference operator*() const { return *ptr; }
    pointer operator->() const { return ptr; }

        // Конструкторы
        OneIterator() noexcept: ptr(nullptr)  {}

        template<bool other_const>
        OneIterator(const OneIterator<T, other_const>& o) noexcept
          // нельзя из неконстантного в константный
          requires (is_const >= other_const){ptr = o.ptr;}

        template<bool other_const>
        OneIterator& operator = (const OneIterator<T, other_const>& o) noexcept
        // нельзя из неконстантного в константный
        requires (is_const >= other_const){ ptr = o.ptr; return *this;}

    OneIterator& operator++() noexcept{
        ++ptr;
        return *this;
    }

    OneIterator operator++(int) noexcept{
        OneIterator temp = *this;
        ++(*this);
        return temp;
    }

    OneIterator& operator--()noexcept{
        --ptr;
        return *this;
    }

    OneIterator operator--(int)noexcept {
        OneIterator temp = *this;
        --(*this);
        return temp;
    }

    OneIterator& operator+=(difference_type offset) {
        ptr += offset;
        return *this;
    }

    OneIterator& operator-=(difference_type offset) {
        ptr -= offset;
        return *this;
    }
    reference operator[](difference_type n) const{
        return *(ptr+n);
    }

    OneIterator operator+(difference_type offset) const { return OneIterator(ptr + offset); }
    OneIterator operator-(difference_type offset) const { return OneIterator(ptr - offset); }


    friend OneIterator operator+(difference_type offset, const OneIterator& it)
     { return OneIterator(it.ptr + offset); }
    difference_type operator-(const OneIterator& other) const { return ptr - other.ptr; }

        bool operator==(const OneIterator& other) const noexcept{ return ptr == other.ptr; }
        bool operator!=(const OneIterator& other) const noexcept{ return !(*this == other); }
        bool operator< (const OneIterator& other) const noexcept{ return ptr < other.ptr; }
        bool operator> (const OneIterator& other) const noexcept{ return ptr > other.ptr; }
        bool operator<=(const OneIterator& other) const noexcept{ return ptr <= other.ptr; }
        bool operator>=(const OneIterator& other) const noexcept{ return ptr >= other.ptr; }

private:
        typedef std::conditional_t<is_const, const T, T>* node_ptr_t;
        node_ptr_t ptr;  // Указатель на элемент в массиве

        explicit OneIterator(node_ptr_t p) : ptr(p) {}

        friend Matrix<T>;

        // Итератор противоположной константности
        // может обращаться к privete полям
        friend OneIterator<T, !is_const>;   
};

static_assert(std::random_access_iterator<OneIterator<int, false>>);
static_assert(std::random_access_iterator<OneIterator<int, true>>);


template <std::default_initializable T>
class Matrix {
public:
        using ValueType = T;
        using OneIteratorType = OneIterator<T, false>;
        using ConstOneIteratorType = OneIterator<T, true>;
            typedef T& reference;
            typedef const T& const_reference;
        // Конструктор по умолчанию
        // Конструктор по умолчанию
        Matrix()
            noexcept(std::is_nothrow_default_constructible_v<T>);
        
        Matrix(std::initializer_list<std::initializer_list<T>> init);

        // Конструктор с заданной ёмкостьюsf 
        Matrix(int rows, int cols)
            requires std::copy_constructible<T>;

        // Конструктор копирования
        Matrix(const Matrix& other)
        requires std::copy_constructible<T>;

        // Конструктор перемещения
        Matrix(Matrix&& other) noexcept(std::is_nothrow_default_constructible_v<T>) requires std::move_constructible<T>;

        // Деструктор
        ~Matrix();

        // Функция для получения количества строк
        int rows() const {// Функция для получения количества строк
                return m_rows;
        }

        // Функция для получения количества столбцов
        int cols() const {// Функция для получения количества столбцов
                return m_cols;
        }
        Matrix& operator=(const Matrix& other)noexcept 
        requires std::copy_constructible<T>
        {
                if (this == &other) return *this;
                Matrix temp(other);
                swap(temp);
                return *this;
        }


        Matrix& operator=(Matrix&& other) noexcept {
                if (this == &other) return *this; // Проверка на самоприсваивание

                // Освобождение текущих ресурсов (если есть)
                clear();

                // Копирование размеров и данных
                m_rows = other.m_rows;
                m_cols = other.m_cols;
                m_data = std::make_unique<std::unique_ptr<T[]>[]>(m_rows);

                for (int i = 0; i < m_rows; ++i) {
                        m_data[i] = std::make_unique<T[]>(m_cols);
                        std::copy(other.m_data[i].get(), other.m_data[i].get() + m_cols, m_data[i].get());
                }

                return *this;
        }

        // Оператор индексации
        T* operator[](int row)
         requires std::is_integral_v<std::remove_cv_t<int>>;

        const T* operator[](int row) const
         requires std::is_integral_v<std::remove_cv_t<int>>;

        // Оператор at
        reference at(int row, int col)
         requires std::is_integral_v<std::remove_cv_t<int>>;
        const_reference at(int row, int col) const
         requires std::is_integral_v<std::remove_cv_t<int>>;

        // Операторы begin и end
        OneIteratorType begin() noexcept;
        OneIteratorType end() noexcept;
        ConstOneIteratorType begin() const noexcept;
        ConstOneIteratorType end() const noexcept;
        ConstOneIteratorType cbegin() const noexcept;
        ConstOneIteratorType cend() const noexcept;

        // Методы для работы с размером и ёмкостью
        int size() const;
        int capacity() const;
        void resize(int new_rows, int new_cols);

        // Методы для добавления и удаления элементов

        void insert(const OneIteratorType& position, const T& value);
        void erase(const OneIteratorType& position){
                insert(position, T());
        }

        void clear();

        // Методы для работы с элементами
        reference front();
        reference back();
        T* data();

        // Методы для проверки состояния контейнера
        bool empty() const;


private:
        void validate_indices(int row, int col) const {
            if (row >= m_rows || col >= m_cols) {
                throw std::out_of_range("Matrix indices out of range");
            }
        }

        void swap(Matrix& other) {
            std::swap(m_rows, other.m_rows);
            std::swap(m_cols, other.m_cols);
            std::swap(m_data, other.m_data);
        }
        int m_rows;
        int m_cols;
        std::unique_ptr<std::unique_ptr<T[]>[]> m_data;
        
};

        template <std::default_initializable T>
        Matrix<T>::Matrix() noexcept(std::is_nothrow_default_constructible_v<T>) : m_rows(1), m_cols(1){
                m_data = std::make_unique<std::unique_ptr<T[]>[]>(1);
                m_data[0] = std::make_unique<T[]>(1);
        }

        template <std::default_initializable T>
        Matrix<T>::Matrix(std::initializer_list<std::initializer_list<T>> init)
        : m_rows(init.size()), m_cols(init.begin() != init.end() ? init.begin()->size() : 0),
        m_data(new std::unique_ptr<T[]>[m_rows]) {
        int row = 0;
        for (const auto& row_init : init) {
                m_data[row] = std::make_unique<T[]>(m_cols);
                int col = 0;
                for (const auto& value : row_init) {
                m_data[row][col] = value;
                ++col;
                }
                ++row;
        }
        }

        // Конструктор с заданной ёмкостью
        template <std::default_initializable T>
        Matrix<T>::Matrix(int rows, int cols)
        requires std::copy_constructible<T>
        : m_rows(rows), m_cols(cols),
                m_data(new std::unique_ptr<T[]>[rows]) {
                for (int i = 0; i < rows; ++i) {
                        m_data[i] = std::make_unique<T[]>(cols);
                }
        }

        // Конструктор копирования
        template <std::default_initializable T>
        Matrix<T>:: Matrix(const Matrix& other)
        requires std::copy_constructible<T> 
        : Matrix(other.m_rows, other.m_cols) {
        for (int i = 0; i < m_rows; ++i) {
                std::copy(other.m_data[i].get(), other.m_data[i].get() + m_cols, m_data[i].get());
        }
        }

        // Конструктор перемещения
        template <std::default_initializable T>
        Matrix<T>::Matrix(Matrix&& other) noexcept(std::is_nothrow_default_constructible_v<T>)
            requires std::move_constructible<T>
        : m_rows(other.m_rows), m_cols(other.m_cols),
                m_data(std::move(other.m_data)){
                other.m_cols = 0;
                other.m_rows = 0;                
        }

        // Деструктор
        template <std::default_initializable T>
        Matrix<T>::~Matrix() {
        clear();
        }


        // Оператор индексации
        template <std::default_initializable T>
        T* Matrix<T>::operator[](int row)
         requires std::is_integral_v<std::remove_cv_t<int>>
          { return m_data[row].get(); }
        
        template <std::default_initializable T>
        const T* Matrix<T>::operator[](int row) const
         requires std::is_integral_v<std::remove_cv_t<int>>
         { return m_data[row].get(); }

        // Оператор at
        template <std::default_initializable T>
        T& Matrix<T>::at(int row, int col) 
         requires std::is_integral_v<std::remove_cv_t<int>>{
                validate_indices(row, col);
                return m_data[row][col];
        }

        template <std::default_initializable T>
        const T& Matrix<T>:: at(int row, int col) const 
         requires std::is_integral_v<std::remove_cv_t<int>>{
                validate_indices(row, col);
                return m_data[row][col];
        }


        template <std::default_initializable T>
        Matrix<T>::OneIteratorType Matrix<T>::begin() noexcept{
                if (m_rows == 0 || m_cols == 0) {
                return Matrix<T>::OneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
                }
                return Matrix<T>::OneIteratorType(&m_data[0][0]); // Возвращаем итератор на первый элемент
        }
        
        template <std::default_initializable T>
        Matrix<T>::OneIteratorType Matrix<T>::end() noexcept {
        if (m_rows == 0 || m_cols == 0) {
            return Matrix<T>::OneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
        }
        return Matrix<T>::OneIteratorType(&m_data[0][0] + (m_rows * m_cols)); // Возвращаем итератор на элемент, следующий за последним
        }

        template <std::default_initializable T>
        Matrix<T>::ConstOneIteratorType Matrix<T>::begin() const noexcept{
                if (m_rows == 0 || m_cols == 0) {
                return Matrix<T>::ConstOneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
                }
                return Matrix<T>::ConstOneIteratorType(&m_data[0][0]); // Возвращаем итератор на первый элемент
        }
        
        template <std::default_initializable T>
        Matrix<T>::ConstOneIteratorType Matrix<T>::end()const noexcept {
        if (m_rows == 0 || m_cols == 0) {
            return Matrix<T>::ConstOneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
        }
        return Matrix<T>::ConstOneIteratorType(&m_data[0][0] + (m_rows * m_cols)); // Возвращаем итератор на элемент, следующий за последним
    }

        template <std::default_initializable T>
        Matrix<T>::ConstOneIteratorType Matrix<T>::cbegin() const noexcept{
                if (m_rows == 0 || m_cols == 0) {
                return Matrix<T>::ConstOneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
                }
                return Matrix<T>::ConstOneIteratorType(&m_data[0][0]); // Возвращаем итератор на первый элемент
        }
        
        template <std::default_initializable T>
        Matrix<T>::ConstOneIteratorType Matrix<T>::cend() const noexcept {
        if (m_rows == 0 || m_cols == 0) {
            return Matrix<T>::ConstOneIteratorType(nullptr); // Возвращаем итератор на nullptr для пустой матрицы
        }
        return Matrix<T>::ConstOneIteratorType(&m_data[0][0] + (m_rows * m_cols)); // Возвращаем итератор на элемент, следующий за последним
    }


        // Методы для работы с размером и ёмкостью
        template <std::default_initializable T>
        int Matrix<T>::size() const { return m_rows * m_cols; }
        template <std::default_initializable T>
        int Matrix<T>::capacity() const { return m_rows * m_cols; }

        template <std::default_initializable T>
        void Matrix<T>::resize(int new_rows, int new_cols) {
                Matrix temp(new_rows, new_cols);
                int min_rows = std::min(m_rows, new_rows);
                int min_cols = std::min(m_cols, new_cols);
                for (int i = 0; i < min_rows; ++i) {
                        std::copy(m_data[i].get(), m_data[i].get() + min_cols, temp.m_data[i].get());
                }
                swap(temp);
        }


        template <std::default_initializable T>
        void Matrix<T>::clear() {
                 // Удаляем динамически выделенные массивы для каждой строки
                for (int i = 0; i < m_rows; ++i) {
                        m_data[i].reset(); // Освобождаем память, выделенную для строки
                }
                // Удаляем массив указателей на строки
                m_data.reset(); // Освобождаем память, выделенную для массива указателей
                m_rows = 0; // Сбрасываем количество строк
                m_cols = 0; // Сбрасываем количество столбцов
        }

        // Методы для работы с элементами
        template <std::default_initializable T>
        T& Matrix<T>::front() { return m_data[0][0]; }
        template <std::default_initializable T>
        T& Matrix<T>::back() { return m_data[m_rows - 1][m_cols - 1]; }
        template <std::default_initializable T>
        T* Matrix<T>::data() { return m_data[0].get(); }

        // Методы для проверки состояния контейнера
        template <std::default_initializable T>
        bool Matrix<T>::empty() const 
        { return m_rows == 0 || m_cols == 0; }

        template <std::default_initializable T>
        void Matrix<T>::insert(const OneIteratorType& position, const T& value) {
        // Проверяем, что итератор указывает на допустимый элемент
        if (position < begin() || position >= end()) {
                throw std::out_of_range("Iterator out of range");
        }

        // Находим индекс строки и столбца, на который указывает итератор
        int index = position - begin(); // Получаем индекс элемента
        int row = index / m_cols; // Вычисляем номер строки
        int col = index % m_cols; // Вычисляем номер столбца

        // Заменяем значение на новое
        m_data[row][col] = value;
        }


} // namespace dang

#endif // DANG_H