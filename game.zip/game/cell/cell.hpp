#ifndef ITER
#define ITER

#include "../item/item.hpp"


namespace creature{
/**
 * @brief  A creature that can move and attack.
 * 
 */
class Enemy;
}

namespace cell{

/**
 * @brief  A cell that can be occupied by a creature.
 * 
 */
enum class type_point {
        nothing,
        stair_up,
        stair_down,
        exit,
        open_door,
        wall,
        chest,
        closed_door,
};

/**
 * @brief  A cell that can be occupied by a creature.
 * 
 */
class Cell {
        private: 
        /** @brief  The type of the cell. 
         * 
        */
        type_point type = type_point::nothing;
        /** @brief  The creature that occupies the cell.
         *      
         */
        creature::Creature * creture = nullptr;
        /**
         * @brief  The item that is in the cell.
         * 
         */
        item::Item * item = nullptr;
        public:
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell() = default;
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(type_point type) : type(type) {}
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(type_point type, creature::Creature * creture) : type(type){
                if(!creture) throw std::invalid_argument("Enemy is nullptr");
                this->creture = creture;
        }
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(type_point type, item::Item * item) : type(type){
                if(!item) throw std::invalid_argument("item is nullptr");
                this->item = item;
        }
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(type_point type, creature::Creature * creture, item::Item * item) : type (type){
                if(!creture) throw std::runtime_error("Enemy is null");
                if(!item)  throw std::runtime_error("Item is null");
                this->creture = creture;
                this->item = item;
        }
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(const Cell& other) = default;
        /**
         * @brief Construct a new Cell object
         * 
         */
        Cell(Cell&& other) = default;
        /**
         * @brief  copy the Cell object
         * 
         * @param other cell
         * @return Cell&  
         */
        Cell& operator=(const Cell& other) = default;
        /**
         * @brief  move the Cell object
         * 
         * @param other  cell
         * @return Cell&  
         */
        Cell& operator=(Cell&& other) = default;
        ~Cell() = default;
        /**
         * @brief  get the type of the cell
         * 
         */
        void open_door(){
                if(type == type_point::closed_door){
                        type = type_point::open_door;
                } else if(type == type_point::open_door) {
                        throw std::runtime_error("Door is already open");
                }else throw std::runtime_error("You are not in the door");
        }
        /**
         * @brief  get the type of the cell
         * 
         */
        void close_door(){
                if(type == type_point::open_door){
                        type = type_point::closed_door;
                } else if(type == type_point::closed_door) {
                        throw std::runtime_error("Door is already close");
                }else throw std::runtime_error("You are not in the door");
        }
        /**
         * @brief Set the creture object
         * 
         * @param creture 
         */
        void set_creture(creature::Creature * creture){
                if(static_cast<int>( type) <5){
                        this->creture = creture;
                }
                else throw std::runtime_error("This cell is not empty");
        }
        /**
         * @brief Set the item object
         * 
         * @param item 
         */
        void set_item(item::Item * item){
                if(static_cast<int>( type) <5||  type == type_point::chest){
                        this->item = item;
                }
        }/**
         * @brief Set the type object
         * 
         * @param type 
         */
        void set_type(type_point type){
                this->type = type;
        }/**
         * @brief Get the type object
         * 
         * @return type_point 
         */
        type_point get_type() const{
                return type;
        }
        /**
         * @brief Get the creture object
         * 
         * @return creature::Creature* 
         */
        creature::Creature * get_creture() const{ return creture; }
        /**
         * @brief Get the item object
         * 
         * @return item::Item* 
         */
        item::Item * get_item() const{ return item; }



};



}

#endif