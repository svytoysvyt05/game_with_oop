#include "characteristics.hpp"
#include "creater/creater.hpp"
#include "dang/dang.hpp"
#include "equip.hpp"
#include <shared_mutex>
#include <thread>
#include <ctime>
#include <vector>
#include <chrono> 
namespace dang{

void move_enemy1(dang* dang, creature::Enemy* enemy){
        int n_x_player = dang->get_player()->get_X_pos();
        int n_y_player = dang->get_player()->get_Y_pos();
        std::vector<creature::direction>  path;
	path = findPath(*(dang->get_map()), {enemy->get_Y_pos(), enemy->get_X_pos()},
	{n_y_player, n_x_player});
        if (!path.empty()){
                for(int i = 0; i < std::min(static_cast<int>( path.size())-1, enemy->get_characteristics().get_speed()); i++){
                        if( abs(enemy->get_X_pos() - n_x_player) <= enemy->get_weapen().get_distance() &&
                        abs(enemy->get_Y_pos() - n_y_player) <= enemy->get_weapen().get_distance()){
                                break;
                        }
                        try{
                                enemy->move(*(dang->get_map()), path[i]);
                        } catch(...){
                                break;
                        } 
                }
        }
        if( abs(enemy->get_X_pos() - n_x_player) <= enemy->get_weapen().get_distance() &&
         abs(enemy->get_Y_pos() - n_y_player) <= enemy->get_weapen().get_distance()){
                enemy->attack(dang->get_player());
         }

}
void move_person_iter1(dang* dang){
        std::vector<creature::Enemy*> enemies;
        enemies.reserve(dang->get_initiative().size()-1);
        for ( auto creat: dang->get_initiative()){
                if( dynamic_cast<creature::Enemy*>(creat) != nullptr){                              
                        creature::Enemy* enemy = dynamic_cast<creature::Enemy*>(creat);
                        if (enemy->get_HP() > 0) {
				move_enemy1(dang, enemy);
				enemy->tic();
                        }
                }
        }

}

void move_person_iter(dang* dang){
        std::vector<creature::Enemy*> enemies;
        enemies.reserve(dang->get_initiative().size()-1);
        for ( auto creat: dang->get_initiative()){
                if( dynamic_cast<creature::Enemy*>(creat) != nullptr){                              
                        creature::Enemy* enemy = dynamic_cast<creature::Enemy*>(creat);
                        if (enemy->get_HP() > 0) {
                                enemies.push_back(enemy);
                        }
                }
        }
        std::vector<std::thread> threads;


	auto num = std::thread::hardware_concurrency();
	if ( num == 0) num = 64;
	threads.reserve(num);
	int size =  enemies.size();
	for (int i = 0; i < num; i++) {
		int start = i * size / num;
		int end = std::min((int) ((1+i) * size / num), size);
		threads.emplace_back([dang, enemies, start, end]() {
		for (int j = start; j < end; j++) {
			creature::Enemy* enemy = enemies[j];
			dang->move_enemy(enemy);
			enemy->tic();
		}
	});
	}

        for (auto& t : threads) {
                t.join();
        }
}
}

int main() {
	std::ofstream file1("file1.txt");
	std::ofstream file2("file2.txt");
	if (!file1.is_open() || !file2.is_open()) {
		std::cerr << "Ошибка открытия файлов!" << std::endl;
		return 1;
	}
	for(int n = 20; n <= 200; n+=20){
		// Размер карты
		std::srand(static_cast<unsigned>(std::time(nullptr)));

		// Создаём карту n x n
		dang::Matrix<cell::Cell>* map = new dang::Matrix<cell::Cell>(n, n);

		std::vector<creature::Charasteristic> base_characteristics;
		
		for(int i = 0; i < 6; i++){
			base_characteristics.push_back(creature::Charasteristic{static_cast<creature::type_charasteristic>(i), 14, 1,1});
		} 
		// Генерация случайных типов клеток
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
			cell::type_point cell_type = (std::rand() % 2 == 0) ? cell::type_point::nothing : cell::type_point::wall;
			(*map)[i][j].set_type(cell_type);
			}
		}

		// Создаём n врагов
		std::vector<creature::Enemy*> enemies;
		for (int i = 0; i < n; ++i) {
			std::string enemy_name = "Enemy_" + std::to_string(i + 1);
			creature::Enemy* enemy = new creature::Enemy(enemy_name, 10, 10, "humanoid", new creature::Characteristics_table{base_characteristics, 10},
			nullptr, 0, 0, new item::Weapon{}, nullptr);
			enemies.push_back(enemy);
		}

		// Создаём игрока
		creature::Player* player = new creature::Player("Player_bot", new creature::Characteristics_table{base_characteristics, 1000000000},"humanoid", nullptr, 0, 0);

		// Добавляем врагов и игрока на карту
		for (creature::Enemy* enemy : enemies) {
			int x, y;
			do {
			x = std::rand() % n;
			y = std::rand() % n;
			} while ((*map)[x][y].get_creture() != nullptr || (*map)[x][y].get_type() == cell::type_point::wall);

			(*map)[x][y].set_creture(enemy);
			enemy->set_X_pos(x);
			enemy->set_Y_pos(y);
			enemy->set_cell(&(*map)[x][y]);
		}

		int player_x, player_y;
		do {
			player_x = std::rand() % n;
			player_y = std::rand() % n;
		} while ((*map)[player_x][player_y].get_creture() != nullptr || (*map)[player_x][player_y].get_type() == cell::type_point::wall);

		(*map)[player_x][player_y].set_creture(player);
		player->set_X_pos(player_x);
		player->set_Y_pos(player_y);
		player->set_cell(&(*map)[player_x][player_y]);

		// Создаём объект Dang и запускаем игру
		dang::dang* game = new dang::dang{player, map};
		for( size_t i = 0; i < enemies.size(); ++i){
			game->add_initiative(dynamic_cast<creature::Creature*>(enemies[i]));
		}

		// Начало измерения времени
		std::chrono::high_resolution_clock::time_point start = std::chrono::high_resolution_clock::now();

		for (int i = 0; i < 100; ++i) {
			(*map)[player_x][player_y].set_creture(nullptr);
			do {
				player_x = std::rand() % n;
				player_y = std::rand() % n;
			} while ((*map)[player_x][player_y].get_creture() != nullptr || (*map)[player_x][player_y].get_type() == cell::type_point::wall);
			player->set_cell(&(*map)[player_x][player_y]);
			(*map)[player_x][player_y].set_creture(player);
			player->set_X_pos(player_x);
			player->set_Y_pos(player_y);
			
			move_person_iter(game);
		}
		// Конец измерения времени
		std::chrono::high_resolution_clock::time_point end = std::chrono::high_resolution_clock::now();

		// Вычисляем время выполнения
		std::chrono::microseconds duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);

		// Начало измерения времени
		std::chrono::high_resolution_clock::time_point start1 = std::chrono::high_resolution_clock::now();

		for (int i = 0; i < 100; ++i) {
			(*map)[player_x][player_y].set_creture(nullptr);
			do {
				player_x = std::rand() % n;
				player_y = std::rand() % n;
			} while ((*map)[player_x][player_y].get_creture() != nullptr || (*map)[player_x][player_y].get_type() == cell::type_point::wall);
			player->set_cell(&(*map)[player_x][player_y]);
			(*map)[player_x][player_y].set_creture(player);
			player->set_X_pos(player_x);
			player->set_Y_pos(player_y);
			
			move_person_iter1(game);
		}
		// Конец измерения времени
		std::chrono::high_resolution_clock::time_point end1 = std::chrono::high_resolution_clock::now();

		// Вычисляем время выполнения
		std::chrono::microseconds duration1 = std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1);

		// Освобождаем память
		delete game;
		file1 << duration.count() << std::endl;
		file2 << duration1.count() << std::endl;
		std::cout << "Время выполнения на "<< n << " карте 100 функциях с потоками:  " << duration.count() << " микросекунд" << std::endl;
		std::cout << "Время выполнения на "<< n << " карте 100 функциях без потоков: " << duration1.count() << " микросекунд" << std::endl;
	
	}
	file1.close();
    	file2.close();
	return 0;
}
