/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <map>
#include <queue>
#include <utility>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <iterator>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <fstream>
#include <iostream>
using namespace std;
int main()
{
        std::fstream item;
        item.open("item_1.txt");
        int type;
        while(item >> type){
                cout << " type: " << type << endl;
                int min_damage, max_damage, distance, type_c;
                string name, description, enchanteds_s;
                int value, max_HP, speed, move, dop_armor, type_armor;
                int charac[6][3]; 
                std::istringstream stream1;
                std::vector<std::string> enchanteds_vec;
                switch (type){
                case 1:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        item >> min_damage >> max_damage >> distance >> type_c;
                        break;
                case 2:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);

                        item >> value;
                        break;
                case 3:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        item >> dop_armor >> type_armor;
                        break;
                case 4:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        item >> value>> max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        item >> move;

                        break;
                case 5:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        std::getline(item, enchanteds_s);
                        stream1.str(enchanteds_s);


                        // Разделяем строку на слова и сохраняем их в вектор
                        std::copy(std::istream_iterator<std::string>(stream1),
                                std::istream_iterator<std::string>(),
                                std::back_inserter(enchanteds_vec));
                        item >> min_damage >> max_damage >> distance >> type_c;
                        cout <<endl;
                        break;
                case 6:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        item >> min_damage >> max_damage >> distance >> type_c;
                        item >>  max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }

                        break;
                case 7:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        std::getline(item, enchanteds_s);
                        stream1.str(enchanteds_s);
                        item >> min_damage >> max_damage >> distance >> type_c;
                        item >>  max_HP >> speed;
                        std::copy(std::istream_iterator<std::string>(stream1),
                                std::istream_iterator<std::string>(),
                                std::back_inserter(enchanteds_vec));
                        
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                cout << charac[i][0] << " " << charac[i][1] << " " << charac[i][2] << endl;
                        }
                        for(string s : enchanteds_vec){ cout << s << " ";}
                        cout <<endl;
                        cout << name << endl << description << endl << min_damage << endl << max_damage << endl << distance << endl << type_c << endl;
                         cout << max_HP << endl << 100000 << endl << speed << endl << endl;
                        break;
                case 8:
                        item.ignore(100, '\n');
                        std::getline(item, name);
                        std::getline(item, description);
                        item >> dop_armor >> type_armor;

                        item >> max_HP >> speed;
                        for(int i = 0; i < 6; i++){
                                for(int j = 0; j < 3; j++){
                                        item >> charac[i][j];
                                }
                        }
                        for(int i = 0; i < 6; i++){
                                cout << charac[i][0] << " " << charac[i][1] << " " << charac[i][2] << endl;
                        }
                        cout << name << endl << dop_armor << endl <<  type_armor << endl << max_HP << endl << 1000 << endl << speed  << endl << description.size() << endl << endl ;
                        break;

                default:
                        break;
                }
        }
    return 0;
}