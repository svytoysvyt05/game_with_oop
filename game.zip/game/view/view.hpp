#ifndef VIEW_H
#define VIEW_H
#include <iostream>
#include <locale.h>
#include <ncurses.h>
#include "../cell/cell.hpp"
#include "../creater/creater.hpp"
#include "../level/level.hpp"

#include <string>
#include <thread>

namespace dang{
    class dang;
}

namespace view{

class MapRenderer {

private:
    
    // Карта
    dang::Matrix<cell::Cell> *map;
    int cursor_x = 0;
    int cursor_y = 0;
    void initColors() {
        start_color();
        init_pair(1, COLOR_WHITE, COLOR_BLACK);  // Default color
        init_pair(2, COLOR_BLUE, COLOR_BLACK);   // Stair Up
        init_pair(3, COLOR_CYAN, COLOR_BLACK);   // Stair Down
        init_pair(4, COLOR_GREEN, COLOR_BLACK);  // Exit
        init_pair(5, COLOR_WHITE, COLOR_BLACK); // Open Door
        init_pair(6, COLOR_WHITE, COLOR_BLACK);    // Wall
        init_pair(7, COLOR_YELLOW, COLOR_BLACK);// Chest
        init_pair(8, COLOR_WHITE, COLOR_BLACK);  // Closed Door
        init_pair(9, COLOR_CYAN, COLOR_BLACK);  // Player
        init_pair(10, COLOR_RED, COLOR_BLACK);  // Enemy
        init_pair(11, COLOR_WHITE, COLOR_WHITE);  // cursor
    }

    void drawCell(const cell::Cell& cell, bool highlight);


    void displayInfo(const cell::Cell& cell);

    void clearInfo() {
        for (size_t i = 0; i < 20; ++i) {
            move(i, map->cols() + 2);
            clrtoeol();
        }
    }


public:
    void deinit(){
        endwin();
    }
    MapRenderer(dang::Matrix<cell::Cell>* map) : map(map) {
        initscr();
        noecho();
        cbreak();
        keypad(stdscr, TRUE);
        curs_set(0);
        initColors();
        resize_term(50, 150);
    }

    ~MapRenderer()= default;
    void end_game(bool win) {
            clear();
            mvprintw(0, 0, "Game Over!");        
            if (win){
                    mvprintw(2, 0, "You Win!");
            } else  {
                     mvprintw(2, 0, "You Lose!");
            }
    }
    void render(bool f = true) {
        if(f){
            clear();
            resize_term(50, 150);
        }
        for (int y = 0; y < map->rows(); y++) {
                for (int x = 0; x < map->cols(); x++) {
                    move(y, x);
                    drawCell((*map)[y][x],  x == cursor_x && y == cursor_y);
                }
        }
        displayInfo((*map)[cursor_y][cursor_x]);
        if(f)refresh();
    }
    int move_player(creature::Player* player);
};
}
#endif // VIEW_H