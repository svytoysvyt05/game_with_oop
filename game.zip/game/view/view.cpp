#include "view.hpp"
#include "../dang/dang.hpp"
#include "../openned/openned.hpp"
#include "cell.hpp"
#include "creater.hpp"
#include "level.hpp"

namespace view{
    void MapRenderer::drawCell(const cell::Cell& cell, bool highlight) {
        if (highlight) {
                attron(COLOR_PAIR(11));
                addch(' ');
        }else{
        if( cell.get_creture() && dynamic_cast<creature::Player*>(cell.get_creture()) != nullptr ) {
                attron(COLOR_PAIR(3));
                addch('P');
        }
        if( cell.get_creture() && dynamic_cast<creature::Enemy*>(cell.get_creture()) != nullptr ) {
                attron(COLOR_PAIR(10));
                addch('E');
        }
        if( cell.get_item() && cell.get_type() != cell::type_point::chest ) {
                attron(COLOR_PAIR(6));
                addch('i');
        }else{
                switch (cell.get_type()) {
                case cell::type_point::nothing:
                        attron(COLOR_PAIR(1));
                        addch('.');
                        break;
                case cell::type_point::stair_up:
                        attron(COLOR_PAIR(2));
                        addch('^');
                        break;
                case cell::type_point::stair_down:
                        attron(COLOR_PAIR(3));
                        addch('v');
                        break;
                case cell::type_point::exit:
                        attron(COLOR_PAIR(4));
                        addch('X');
                        break;
                case cell::type_point::open_door:
                        attron(COLOR_PAIR(5));
                        addch('.');
                        break;
                case cell::type_point::wall:
                        attron(COLOR_PAIR(6));
                        addch('#');
                        break;
                case cell::type_point::chest:
                        attron(COLOR_PAIR(7));
                        addch('$');
                        break;
                case cell::type_point::closed_door:
                        attron(COLOR_PAIR(8));
                        addch('%');
                        break;
                }
        }}
        
        if (highlight) {
            attroff(COLOR_PAIR(11));
        }else attroff(A_STANDOUT);
    }


void MapRenderer::displayInfo(const cell::Cell& cell) {
        int io = 0;
        move(0, map->cols() + 2);
        clearInfo();
        move(0, map->cols() + 2);
        attron(COLOR_PAIR(1));
        // Display cell type
        printw("Cell Type: ");
        switch (cell.get_type()) {
            case cell::type_point::nothing:
                printw("Nothing\n");
                break;
            case cell::type_point::stair_up:
                printw("Stair Up\n");
                break;
            case cell::type_point::stair_down:
                printw("Stair Down\n");
                break;
            case cell::type_point::exit:
                printw("Exit\n");
                break;
            case cell::type_point::open_door:
                printw("Open Door\n");
                break;
            case cell::type_point::wall:
                printw("Wall\n");
                break;
            case cell::type_point::chest:
                printw("Chest\n");
                break;
            case cell::type_point::closed_door:
                printw("Closed Door\n");
                break;
        }
        // Display item info if present
        if (cell.get_item() != nullptr) {
            move(++(++io), map->cols() +2);
            const item::Item* item = cell.get_item();
            printw("Item: %s", item->get_name().c_str());
            move(++io, map->cols() +2);
            printw("Description: %s", item->get_description().c_str());
            move(++io, map->cols() +2);
            printw("Value: %d\n", item->get_value());
            if( dynamic_cast<const item::Chest*>(cell.get_item()) != nullptr ){
                move(++io, map->cols() +2);
                const item::Chest * chest = dynamic_cast<const item::Chest*>(cell.get_item());
                printw("Openned: %d", chest->get_open());
                if(chest->get_items()){
                        move(++io, map->cols() +2);
                        printw("Item name: %s", chest->get_items()->get_name().c_str());
                }
            }
        
        }
        // Display creature info if present
        if (cell.get_creture() != nullptr) {
                move(++(++io), map->cols() +2);
                const creature::Creature* creature = cell.get_creture();
                printw("Creature: %s", creature->get_name().c_str());
                move(++io, map->cols() +2);
                printw("HP: %d", creature->get_HP());
                move(++io, map->cols() +2);
                printw("Armor Class: %d", creature->get_armor_class());
                move(++io, map->cols() +2);
                printw("Speed: %d", creature->get_characteristics().get_speed());
                move(++io, map->cols() +2);
                printw("Feature: %s\n", creature->get_feature().c_str());
                if( dynamic_cast<const creature::Player*>(creature) != nullptr ) {
                        const creature::Player* a = dynamic_cast<const creature::Player*>(creature);
                        move(++(io), map->cols() +2);
                        printw("Level: %d", a->get_level());
                        move(++(io), map->cols() +2);
                        printw("XP: %d", a->get_XP());
                        move(++(io), map->cols() +2);
                        printw("Masters keys: %d", a->get_master_keys().get_value());
                        move(++(io), map->cols() +2);
                        printw("Your Potion: ");
                        for( size_t i = 0; i < a->get_potions().size(); i++ ) {
                                printw(" %s, ", a->get_potions()[i].get_name().c_str());
                        }

                }else if ( dynamic_cast<const creature::Enemy*>(creature) != nullptr ) {
                        const creature::Enemy* a = dynamic_cast<const creature::Enemy*>(creature);
                        move(++(io), map->cols() +2);
                        printw("XP: %d", a->get_XP());                
                }
        }
        refresh();
    }

int MapRenderer::move_player( creature::Player* player) {
        int ch, number_flag=0;
        int n_x, n_y;
        while ((ch = getch()) != 27) { // Press 'q' to exit
        try{
                clear();
                refresh();
                switch (ch) {
                        case KEY_UP:
                                if (cursor_y > 0) --cursor_y;
                                break;
                        case KEY_DOWN:
                                if (cursor_y <map->rows() - 1) ++cursor_y;
                                break;
                        case KEY_LEFT:
                                if (cursor_x > 0) --cursor_x;
                                break;
                        case KEY_RIGHT:
                                if (cursor_x < map->cols() - 1) ++cursor_x;
                                break;
                        case 5:
                                return 5;

                        case 'q':
                                move(map->rows() + 1, map->cols() + 2);
                                printw("all your speed left");
                                move( cursor_x, cursor_y);
                                return 0;
                        case 'w':
                                move(map->rows() + 1, map->cols() + 2);
                                if((player->get_characteristics().get_speed()-player->get_speed_now())>0){
                                        player->move(*map, creature::direction::forward);
                                        printw("%d\\%d speed left", player->get_speed_now(), player->get_characteristics().get_speed());
                                } else printw("all your speed left");
                                move( cursor_x, cursor_y);
                                break;
                        case 's':
                                move(map->rows() + 1, map->cols() + 2);
                                if((player->get_characteristics().get_speed()-player->get_speed_now())>0){
                                        player->move(*map, creature::direction::back);
                                        printw("%d\\%d speed left", player->get_speed_now(), player->get_characteristics().get_speed());
                                } else printw("all your speed left");
                                move( cursor_x, cursor_y);
                                break;
                        case 'a':
                                move(map->rows() + 1, map->cols() + 2);
                                if((player->get_characteristics().get_speed()-player->get_speed_now())>0){
                                        player->move(*map, creature::direction::left);
                                        printw("%d\\%d speed left", player->get_speed_now(), player->get_characteristics().get_speed());
                                } else printw("all your speed left");
                                move( cursor_x, cursor_y);
                                break;
                        case 'd':
                                move(map->rows() + 1, map->cols() + 2);
                                if((player->get_characteristics().get_speed()-player->get_speed_now())>0){
                                        player->move(*map, creature::direction::right);
                                        printw("%d\\%d speed left", player->get_speed_now(), player->get_characteristics().get_speed());
                                } else printw("all your speed left");
                                move( cursor_x, cursor_y);
                                break;
                        case 'u':
                                if( number_flag >= player->get_characteristics().get_speed()/2){
                                        move(map->rows() + 2, map->cols() + 2);
                                        printw("all your actions left\n");
                                        move( cursor_x, cursor_y);
                                        break;
                                }
                                n_x = player->get_X_pos();
                                n_y = player->get_Y_pos();
                                if(  n_x == cursor_x && n_y == cursor_y &&
                                 (*map)[cursor_y][cursor_x].get_type() == cell::type_point::stair_down) return -1;
                                if(  n_x == cursor_x && n_y == cursor_y &&
                                 (*map)[cursor_y][cursor_x].get_type() == cell::type_point::stair_up) return 1;
                                if( abs(n_x - cursor_x) <= 1 && abs(n_y - cursor_y) <= 1){
                                        if((*map)[cursor_y][cursor_x].get_item()){
                                                player->use_item( (*map)[cursor_y][cursor_x].get_item());
                                        }
                                        number_flag++;
                                } else{
                                        move(map->rows() + 1, map->cols() + 2);
                                        printw("You are too far\n");
                                        move( cursor_x, cursor_y);

                                }
                                move(map->rows() + 2, map->cols() + 2);
                                printw("%d\\%d speed left", number_flag+1, player->get_characteristics().get_speed()/2);
                                move( cursor_x, cursor_y);
                                break;
                        case 'e':
                                if( number_flag >= player->get_characteristics().get_speed()/2){
                                        move(map->rows() + 2, map->cols() + 2);
                                        printw("all your actions left\n");
                                        move( cursor_x, cursor_y);
                                        break;
                                }
                                n_x = player->get_X_pos();
                                n_y = player->get_Y_pos();
                                if( abs(n_x - cursor_x) <= 1 && abs(n_y - cursor_y) <= 1){
                                        if((*map)[cursor_y][cursor_x].get_item()){
                                                if(player->equip( (*map)[cursor_y][cursor_x].get_item())){
                                                        (*map)[cursor_y][cursor_x].set_item(nullptr);
                                                }
                                        }
                                        number_flag++;
                                } else{
                                        move(map->rows() + 1, map->cols() + 2);
                                        printw("You are too far\n");
                                        move( cursor_x, cursor_y);

                                }
                                move(map->rows() + 2, map->cols() + 2);
                                printw("%d\\%d speed left", number_flag+1, player->get_characteristics().get_speed()/2);
                                move( cursor_x, cursor_y);
                                break;
                        case 10:                                
                                if( number_flag >= player->get_characteristics().get_speed()/2){
                                        move(map->rows() + 2, map->cols() + 2);
                                        printw("all your actions left\n");
                                        move( cursor_x, cursor_y);
                                        break;
                                }
                                n_x = player->get_X_pos();
                                n_y = player->get_Y_pos();
                                if((*map)[cursor_y][cursor_x].get_creture()){
                                        try{
                                                player->attack((*map)[cursor_y][cursor_x].get_creture());
                                                number_flag++;
                                        }catch(...){
                                                move(13,12);
                                                printw("You are too far\n");
                                                move(cursor_x, cursor_y);

                                        }
                                }else{
                                                move(map->rows() + 1, map->cols() + 2);
                                                printw("It isn't Enemy");
                                                move(cursor_x, cursor_y);

                                }


                                move(map->rows() + 2, map->cols() + 2);
                                printw("%d\\%d speed left", number_flag+1, player->get_characteristics().get_speed()/2);
                                move( cursor_x, cursor_y);
                                break;

                        default:
                                if( ch>='0' && ch<='9'){
                                        if( number_flag >= player->get_characteristics().get_speed()/2){
                                                move(map->rows() + 1, map->cols() + 2);
                                                printw("all your actions left\n");
                                                move( cursor_x, cursor_y);
                                                break;
                                        }
                                        int number = ch - '0';
                                        if( !number ) number = 10;
                                        number_flag++;
                                        player->use_my_potion(number);
                                }
                                break;
                }
                }catch (const std::exception& e){
                        move(map->rows() + 2, map->cols() + 2);
                        printw("%s",e.what());
                        move( cursor_x, cursor_y);
                }
        render( false);
        }
        return 0;
    }
}