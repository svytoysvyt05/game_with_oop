#ifndef OPEN_H
#define OPEN_H
#include "../item/item.hpp"
namespace creature{
class Characteristics_table;
}
namespace item{

class Opened{        
        protected:
        
        int difficulty_class = 10;
        bool is_open = false;
        public:
        /**
         * @brief Construct a new Opened object
         * 
         */
        Opened() = default;
        virtual ~Opened() = default;
        Opened(int difficulty_class, bool is_open = false): difficulty_class(difficulty_class), is_open(is_open) {
                if(difficulty_class > 0 || is_open){
                        this->difficulty_class = difficulty_class;
                } else throw std::invalid_argument("Difficulty class must be greater than 0");
        }
/**
 * @brief Get the difficulty object
 * 
 * @return int 
 */
        int get_difficulty() const{
                return this->difficulty_class;
        }
        /**
         * @brief Set the difficulty object
         * 
         * @param difficulty_class 
         */
        void set_difficulty(int difficulty_class){
                if(difficulty_class > 0){
                        this->difficulty_class = difficulty_class;
                }
        }
        /**
         * @brief Set the open object
         * 
         * @param is_open 
         */
        void set_open(bool is_open)  {
                this->is_open = is_open;
                difficulty_class = std::max(1, difficulty_class);
        }
        /**
         * @brief Get the open object
         * 
         * @return true 
         * @return false 
         */
        bool get_open() const { return this->is_open;}
/**
 * @brief openned
 * 
 * @param dex 
 * @return true 
 * @return false 
 */
        virtual bool openned(const creature::Characteristics_table& dex) = 0;
        /**
         * @brief close
         * 
         * @return true 
         * @return false 
         */
        virtual bool close() = 0;
};

/**
 * @brief Chest
 * 
 */
class Chest: public Opened, public Item{

        private:
        Item* items = nullptr;

        public:
/**
 * @brief Construct a new Chest object
 * 
 * @param name 
 * @param description 
 * @param value 
 * @param item 
 * @param difficulty_class 
 * @param is_open 
 */
        Chest(const std::string& name, const std::string& description, int value, Item* item, int difficulty_class = 10, bool is_open = false) :
        Opened(difficulty_class, is_open),  Item(name, value, description){
                this->items = new Item{*item};
        }
/**
 * @brief Construct a new Chest object
 * 
 * @param name 
 * @param description 
 * @param value 
 * @param difficulty_class 
 * @param is_open 
 */
        Chest(const std::string& name, const std::string& description, int value, int difficulty_class = 10, bool is_open = false):
        Opened(difficulty_class, is_open), Item(name, value, description){}

        /**
         * @brief Construct a new Chest object
         * 
         * @param name 
         * @param value 
         * @param item 
         * @param difficulty_class 
         * @param is_open 
         */
        Chest(const std::string& name, int value, Item* item, int difficulty_class = 10, bool is_open = false):
        Opened(difficulty_class, is_open), Item(name, value, "Chest"){
                this->items = new Item{*item};
        }
        /**
         * @brief Construct a new Chest object
         * 
         * @param name 
         * @param value 
         * @param difficulty_class 
         * @param is_open 
         */
        Chest(const std::string& name, int value, int difficulty_class = 10, bool is_open = false):
        Opened(difficulty_class, is_open), Item(name, value, "Chest"){}
/**
 * @brief Construct a new Chest object
 * 
 * @param items 
 * @param difficulty_class 
 */
        Chest(Item* items, int difficulty_class = 10): Opened(10, false), Item("Chest", 1, ""){
                if(items) this->items = items;
                else throw std::invalid_argument("Chest must have an item");
                this->difficulty_class = difficulty_class;
                }
/**
 * @brief Destroy the Chest object
 * 
 */
        ~Chest(){
                if(items) delete items;
        }   
        /**
         * @brief 
         * 
         */
        Chest(): Opened(10, true), Item("Chest", 1, ""), items(nullptr){}
        /**
         * @brief Set the is open object
         * 
         * @param is_open 
         */
        void set_is_open( bool is_open) {this->is_open = is_open;}
        /**
         * @brief Get the is open object
         * 
         * @return true 
         * @return false 
         */
        bool get_is_open() const {return this->is_open;}
        /**
         * @brief Set the items object
         * 
         * @param items 
         */
        void set_items(Item* items){
                this->items = items;
        }
 /**
  * @brief Get the items object
  * 
  * @return Item* 
  */
        Item* get_items() const{
                return this->items;
        }

        /**
         * @brief 
         * 
         * @return Item* 
         */
        Item* take_items(){
                Item *a = this->items->clone();
                delete this->items;
                this->items = nullptr;
                return a;
        }

        /**
         * @brief openned door
         * 
         * @param dex 
         * @return true 
         * @return false 
         */
        bool openned(const creature::Characteristics_table& dex) override;

        /**
         * @brief close door
         * 
         * @return true 
         * @return false 
         */
        bool close() override{
                is_open = false;
                return true;
        }
/**
 * @brief Removed
 * 
 * @param person 
 */
        void Removed(creature::Creature* person) override{
                return;
        }
        /**
         * @brief Puted
         * 
         * @param person 
         */
        void Puted(creature::Creature* person) override{
                return;
        }

        Chest* clone()const override {
                return new Chest(*this);
        }
};

}
#endif // DANG_H