#include "../characteristics/characteristics.hpp"
#include "openned.hpp"
// #include <algorithm>

namespace item{
        bool Chest::openned(const creature::Characteristics_table& dex){
                if (is_open || dex.check_skill(creature::type_charasteristic::Dexterity)> difficulty_class){
                        is_open = true;
                        return true;
                }return false;
        }
}